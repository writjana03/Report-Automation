/* ==========================================================================
   MONTHLY REPORT PIPELINE
   Reads raw Qualys rows (real column schema), applies the Status/Status
   Category fallback rules wherever those are blank, derives Title Group,
   and builds the 4 pivot tables the Monthly PPT is generated from.
   ========================================================================== */

function normalize(s) {
  return String(s == null ? "" : s).toLowerCase().replace(/[^a-z0-9]+/g, " ").trim().replace(/\s+/g, " ");
}

/* ---------------- Title Group derivation ---------------- */
// "Apache Tomcat 9.0 Vulnerabilities" -> "Apache Tomcat"
// Strip known suffix phrases (repeatedly, longest-first within each pass),
// then strip a trailing version-like token, then repeat until stable.
const TITLE_GROUP_SUFFIXES = [
  "Multiple Vulnerabilities", "Vulnerabilities", "Vulnerability", "Multiple",
  "Remote Code Execution Vulnerability", "Remote Code Execution",
  "Privilege Escalation Vulnerabilities", "Privilege Escalation",
  "Operating System Detected", "End-of-Life Detected", "End-of-Life",
  "Default Community String Detected", "Detected"
].sort((a, b) => b.length - a.length);

function deriveTitleGroup(title) {
  let t = String(title || "").replace(/\([^)]*\)/g, "").trim(); // drop "(CVE-...)" etc.
  let changed = true;
  while (changed) {
    changed = false;
    for (const suf of TITLE_GROUP_SUFFIXES) {
      const re = new RegExp("\\s+" + suf.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "$", "i");
      if (re.test(t)) { t = t.replace(re, "").trim(); changed = true; }
    }
    const versionRe = /\s+((v|V)?\d+(\.\d+)*|R\d+)$/;
    if (versionRe.test(t)) { t = t.replace(versionRe, "").trim(); changed = true; }
  }
  return t || String(title || "").trim();
}

/* ---------------- Status / Status Category fallback rules ---------------- */
// Applied ONLY where Status / Status Category are blank on the incoming row.
// Order matters: first matching rule wins.
function applyStatusFallback(r) {
  const status = String(r["Status "] || "").trim();
  const category = String(r["Status Category"] || "").trim();
  if (status && category) return { status, category }; // already populated — take as-is

  const disposition1 = normalize(r["Disposition 1 "]);
  const serverStatus = normalize(r["Server Status"]);
  const remediationType = normalize(r["Remediation Type"]);
  const appHosted = String(r["App(s) Hosted"] || "");
  const sla = String(r["SLA"] || "").trim();

  // Rule 1: Automated Patching + Fixed -> Closed / Closed as per rescan
  if (disposition1 === "automated patching" && serverStatus === "fixed") {
    return { status: "Closed", category: "Closed as per rescan" };
  }
  // Rule 2: Remediation Type = LTR -> RA / LTR
  if (remediationType === "ltr") {
    return { status: "RA", category: "LTR" };
  }
  // Rule 3: App(s) Hosted country = KR -> OOS / OOS-Scope
  if (/^\s*\d+\s*-\s*kr\s*-/i.test(appHosted) || String(r["Server Country"] || "").trim().toUpperCase() === "KR") {
    return { status: "OOS", category: "OOS-Scope" };
  }
  // Rule 4: Outside SLA -> Pending / Ongoing Investigation
  if (sla === "Outside SLA") {
    return { status: "Pending", category: "Ongoing Investigation" };
  }
  // Rule 5: Within SLA -> Pending / Feedback required
  if (sla === "Within SLA") {
    return { status: "Pending", category: "Feedback required" };
  }
  // No rule matched — leave blank rather than guess
  return { status: status || "N/A", category: category || "N/A" };
}

/* ---------------- Main enrichment ---------------- */
function enrichRows(rawRows) {
  return rawRows.map(r => {
    const { status, category } = applyStatusFallback(r);
    return Object.assign({}, r, {
      "Status ": status,
      "Status Category": category,
      "Title Group": deriveTitleGroup(r["Title"])
    });
  });
}

/* ---------------- Pivots ---------------- */
// Pivot 1: Status + Status Category -> count of Asset QID
function pivot1(rows) {
  const map = new Map();
  rows.forEach(r => {
    const key = String(r["Status "]).trim() + " | " + String(r["Status Category"]).trim();
    map.set(key, (map.get(key) || 0) + 1);
  });
  return Array.from(map.entries()).map(([key, count]) => {
    const [status, category] = key.split(" | ");
    return { status, category, count };
  });
}

// Pivot 2: Risk Priority -> count of Asset QID
function pivot2(rows) {
  const map = new Map();
  rows.forEach(r => {
    const key = String(r["Risk Priority"]).trim() || "Unspecified";
    map.set(key, (map.get(key) || 0) + 1);
  });
  return Array.from(map.entries()).map(([riskPriority, count]) => ({ riskPriority, count }))
    .sort((a, b) => Number(a.riskPriority) - Number(b.riskPriority));
}

// Pivot 3: Title Group -> count of Asset QID, optionally filtered by Status/Status Category
function pivot3(rows, filter) {
  const filtered = filter ? rows.filter(filter) : rows;
  const map = new Map();
  filtered.forEach(r => {
    const key = r["Title Group"] || "Unspecified";
    map.set(key, (map.get(key) || 0) + 1);
  });
  return Array.from(map.entries()).map(([titleGroup, count]) => ({ titleGroup, count }))
    .sort((a, b) => b.count - a.count);
}

// Pivot 4: App(s) Hosted -> count of Asset QID, optionally filtered by Status/Status Category
function pivot4(rows, filter) {
  const filtered = filter ? rows.filter(filter) : rows;
  const map = new Map();
  filtered.forEach(r => {
    const key = r["App(s) Hosted"] || "Unspecified";
    map.set(key, (map.get(key) || 0) + 1);
  });
  return Array.from(map.entries()).map(([app, count]) => ({ app, count }))
    .sort((a, b) => b.count - a.count);
}

// Risk Priority -> Severity label mapping (1=Critical .. 5=Low, matching the app's existing convention)
const RISK_PRIORITY_SEVERITY = { "1": "Critical", "2": "High", "3": "Medium", "4": "Low", "5": "Low" };

if (typeof module !== "undefined") {
  module.exports = { enrichRows, deriveTitleGroup, pivot1, pivot2, pivot3, pivot4, RISK_PRIORITY_SEVERITY, normalize };
}
