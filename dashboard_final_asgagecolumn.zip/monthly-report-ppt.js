/* ==========================================================================
   MONTHLY REPORT PPT BUILDER (browser)
   Same slide-by-slide logic already validated via Node (build-ppt.js) —
   just wrapped as a function triggered by the "Monthly Report (PPT)" button,
   using PptxGenJS's native browser download (no filesystem write).
   Depends on globals loaded via <script> tags before this file:
     jszip.min.js, pptxgen.bundle.js, monthly-report-pipeline.js
   Adapted to read the app's own live `allRecords` (see mapRecordsToQualysRows
   below) instead of a separate mock dataset, so the report reflects
   whatever is actually loaded/imported into this dashboard.
   ========================================================================== */

// Converts one of this app's own record objects (camelCase fields, e.g.
// r.application, r.currentStatus) into the raw Qualys-export-style row shape
// (real column names, e.g. "Status ", "App(s) Hosted") that enrichRows() /
// the pivot functions in monthly-report-pipeline.js expect. Only the columns
// that pipeline actually reads are populated - everything else about the
// pipeline and slide-building logic is untouched from the original.
function mapRecordsToQualysRows(records) {
  return (records || []).map(r => ({
    "Asset QID": r.qid || r.assetQID || "",
    "Title": r.vulnerabilityName || "",
    "App(s) Hosted": r.application || "",
    "Server Country": r.serverCountry || r.country || "",
    "Risk Priority": r.riskPriority !== undefined && r.riskPriority !== null ? String(r.riskPriority) : "",
    "SLA": r.sla || "",
    "Remediation Type": r.remediationType || "",
    "Disposition 1 ": r.disposition1 || "",
    "Server Status": r.serverStatus || "",
    "Status ": r.currentStatus || "",
    "Status Category": r.statusCategory || ""
  }));
}

function downloadMonthlyReportPpt() {
  if (typeof JSZip === "undefined" || typeof PptxGenJS === "undefined") {
    if (typeof showToast === "function") showToast("Report engine failed to load — try refreshing the page.", "error");
    return;
  }
  if (typeof allRecords === "undefined" || !allRecords.length) {
    if (typeof showToast === "function") showToast("No records loaded yet — nothing to report on.", "error");
    return;
  }

  // ---- Palette ----
  const NAVY = "1E2761";
  const COVER_BLUE = "2E5AAC";
  const WHITE = "FFFFFF";
  const CHART_BLUE = "2E5AAC";   // last month
  const CHART_ORANGE = "F2994A"; // this month
  const GREEN = "6FCF97";
  const ORANGE_LIGHT = "F2C572";
  const LIGHT_BLUE = "D6E4F5";
  const LIGHT_YELLOW = "FFF3CD";
  const TEXT_DARK = "1A1A2E";
  const GREY_MUTED = "6B7280";

  const now = new Date();

const THIS_MONTH_LABEL = now.toLocaleString("en-US", {
  month: "long"
});

const prevMonth = new Date(
  now.getFullYear(),
  now.getMonth() - 1,
  1
);

const LAST_MONTH_LABEL = prevMonth.toLocaleString("en-US", {
  month: "long"
});

  const enriched = enrichRows(mapRecordsToQualysRows(allRecords));
  const p1 = pivot1(enriched);
  const p2 = pivot2(enriched); // reserved for future slides
  const p3All = pivot3(enriched);
  const p3Closed = pivot3(enriched, r => r["Status "] === "Closed");
  const p3ToFocus = pivot3(enriched, r => r["Status "] !== "Closed" && r["Status "] !== "RA");
  const p4All = pivot4(enriched);

  const STATUS_DISPLAY_ORDER = ["Closed", "Decom path", "In Progress", "Out of Scope", "Pending", "RA"];
  function statusDisplayLabel(rawStatus) { return rawStatus === "OOS" ? "Out of Scope" : rawStatus; }

  const thisMonthByStatus = {};
  STATUS_DISPLAY_ORDER.forEach(s => (thisMonthByStatus[s] = 0));
  p1.forEach(({ status, count }) => {
    const label = statusDisplayLabel(status);
    if (thisMonthByStatus[label] !== undefined) thisMonthByStatus[label] += count;
  });

  // PLACEHOLDER "last month" data — no real prior-month export yet.
  const LAST_MONTH_BY_STATUS = { "Closed": 5, "Decom path": 1, "In Progress": 3, "Out of Scope": 1, "Pending": 8, "RA": 2 };
  const MONTH_WISE_HISTORY = [
    { month: "April", count: 28 },
    { month: "May", count: 25 },
    { month: "June", count: 22 },
    { month: "July", count: 20 },
    { month: LAST_MONTH_LABEL, count: 19 }
  ];
  const thisMonthTotal = Object.values(thisMonthByStatus).reduce((a, b) => a + b, 0);
  MONTH_WISE_HISTORY.push({ month: THIS_MONTH_LABEL, count: thisMonthTotal });

  const SEVERITY_ORDER = ["Critical", "High", "Medium", "Low"];
  const severityTable = {};
  SEVERITY_ORDER.forEach(s => (severityTable[s] = { within: 0, outside: 0 }));
  enriched.forEach(r => {
    const sev = RISK_PRIORITY_SEVERITY[String(r["Risk Priority"]).trim()] || "Low";
    const sla = String(r["SLA"]).trim();
    if (sla === "Within SLA") severityTable[sev].within++;
    else if (sla === "Outside SLA") severityTable[sev].outside++;
  });
  const grandWithin = SEVERITY_ORDER.reduce((sum, s) => sum + severityTable[s].within, 0);
  const grandOutside = SEVERITY_ORDER.reduce((sum, s) => sum + severityTable[s].outside, 0);
  const grandTotalAll = grandWithin + grandOutside;
  const pct = (n, d) => (d > 0 ? Math.round((n / d) * 100) : 0);

  const pres = new PptxGenJS();
  pres.defineLayout({ name: "WIDE", width: 13.33, height: 7.5 });
  pres.layout = "WIDE";

  function addFooter(slide, label) {
    slide.addText(label, { x: 0.5, y: 7.1, w: 8, h: 0.3, fontFace: "Calibri", fontSize: 10, color: GREY_MUTED, isTextBox: true, margin: 0 });
  }
  const CURRENT_YEAR = new Date().getFullYear();
  // ---- Slide 1: Title ----
{
  const slide = pres.addSlide();

  // White Background
  slide.background = { color: WHITE };

  slide.addText("APAC Infra Security", {
    x: 0.8,
    y: 2.5,
    w: 11.7,
    h: 0.9,
    fontFace: "Cambria",
    fontSize: 40,
    bold: true,
    color: COVER_BLUE,
    isTextBox: true,
    margin: 0,
    align: "center"
  });

  slide.addText("Monthly Status Report", {
    x: 0.8,
    y: 3.3,
    w: 11.7,
    h: 0.7,
    fontFace: "Cambria",
    fontSize: 32,
    bold: true,
    color: COVER_BLUE,
    isTextBox: true,
    margin: 0,
    align: "center"
  });

  slide.addText(`${THIS_MONTH_LABEL} ${CURRENT_YEAR}`, {
    x: 0.8,
    y: 4.15,
    w: 11.7,
    h: 0.5,
    fontFace: "Calibri",
    fontSize: 20,
    color: COVER_BLUE,
    isTextBox: true,
    margin: 0,
    align: "center"
  });
}

  // ======================================================
// SLIDE 2
// ======================================================
{
  const slide = pres.addSlide();
  slide.background = { color: WHITE };

  slide.addText("Qualys Server Vulnerabilities — Manual Patching", {
    x: 0.15,
    y: 0.1,
    w: 13,
    h: 0.4,
    fontFace: "Cambria",
    fontSize: 22,
    bold: true,
    color: NAVY
  });

  // --------------------
  // TOP LEFT
  // --------------------
  slide.addChart("bar", [
    {
      name: LAST_MONTH_LABEL,
      labels: STATUS_DISPLAY_ORDER,
      values: STATUS_DISPLAY_ORDER.map(c => LAST_MONTH_BY_STATUS[c])
    },
    {
      name: THIS_MONTH_LABEL,
      labels: STATUS_DISPLAY_ORDER,
      values: STATUS_DISPLAY_ORDER.map(c => thisMonthByStatus[c])
    }
  ], {
    x: 0.15,
    y: 0.65,
    w: 6.1,
    h: 2.8,
    showTitle: true,
    title: "Vulnerability Inflow by Status",
    chartColors: [CHART_BLUE, CHART_ORANGE],
    showValue: true,
    dataLabelPosition: "outEnd",
    showLegend: true,
    legendPos: "b"
  });

  // --------------------
  // TOP RIGHT
  // --------------------
  slide.addChart("bar", [
    {
      name: "Total Vulnerabilities",
      labels: MONTH_WISE_HISTORY.map(m => m.month),
      values: MONTH_WISE_HISTORY.map(m => m.count)
    }
  ], {
    x: 6.75,
    y: 0.65,
    w: 6.1,
    h: 2.8,
    showTitle: true,
    title: "Total Vulnerability Month wise Comparison",
    chartColors: [CHART_BLUE],
    showValue: true,
    dataLabelPosition: "outEnd"
  });

  // --------------------
// BOTTOM LEFT TABLE
// --------------------

slide.addText(
  `Total Outstanding Vulnerabilities — ${THIS_MONTH_LABEL} ${CURRENT_YEAR}`,
  {
    x: 0.15,
    y: 3.55,
    w: 6.1,
    h: 0.3,
    fontSize: 14,
    bold: true,
    color: NAVY
  }
);

const headerRow = [
  {
    text: "Severity",
    options: {
      fill: { color: NAVY },
      color: WHITE,
      bold: true,
      align: "center"
    }
  },
  {
    text: "Within SLA",
    options: {
      fill: { color: "63C48D" },
      color: "000000",
      bold: true,
      align: "center",
      colspan: 2
    }
  },
  {
    text: "Outside SLA",
    options: {
      fill: { color: "F2C35B" },
      color: "000000",
      bold: true,
      align: "center",
      colspan: 2
    }
  },
  {
    text: "Total",
    options: {
      fill: { color: "C8D4E3" },
      color: "000000",
      bold: true,
      align: "center"
    }
  }
];

const subHeaderRow = [
  { text: "", options: { fill: { color: NAVY } } },
  { text: "Count", options: { fill: { color: "63C48D" }, align: "center" } },
  { text: "%", options: { fill: { color: "63C48D" }, align: "center" } },
  { text: "Count", options: { fill: { color: "F2C35B" }, align: "center" } },
  { text: "%", options: { fill: { color: "F2C35B" }, align: "center" } },
  { text: "", options: { fill: { color: "C8D4E3" } } }
];

const outstandingRows = [headerRow, subHeaderRow];

SEVERITY_ORDER.forEach(sev => {
  const w = severityTable[sev].within;
  const o = severityTable[sev].outside;
  const t = w + o;

  outstandingRows.push([
    {
      text: sev,
      options: {
        fill: { color: "F3F4F6" },
        color: NAVY,
        bold: true
      }
    },
    {
      text: String(w),
      options: {
        fill: { color: "F3F4F6" },
        align: "center"
      }
    },
    {
      text: pct(w, t) + "%",
      options: {
        fill: { color: "F3F4F6" },
        align: "center"
      }
    },
    {
      text: String(o),
      options: {
        fill: { color: "F3F4F6" },
        align: "center"
      }
    },
    {
      text: pct(o, t) + "%",
      options: {
        fill: { color: "F3F4F6" },
        align: "center"
      }
    },
    {
      text: String(t),
      options: {
        fill: { color: "DCE6F2" },
        bold: true,
        align: "center"
      }
    }
  ]);
});

outstandingRows.push([
  {
    text: "Total",
    options: {
      fill: { color: "F3E8C2" },
      color: NAVY,
      bold: true
    }
  },
  {
    text: String(grandWithin),
    options: {
      fill: { color: "F3E8C2" },
      bold: true,
      align: "center"
    }
  },
  {
    text: pct(grandWithin, grandTotalAll) + "%",
    options: {
      fill: { color: "F3E8C2" },
      bold: true,
      align: "center"
    }
  },
  {
    text: String(grandOutside),
    options: {
      fill: { color: "F3E8C2" },
      bold: true,
      align: "center"
    }
  },
  {
    text: pct(grandOutside, grandTotalAll) + "%",
    options: {
      fill: { color: "F3E8C2" },
      bold: true,
      align: "center"
    }
  },
  {
    text: String(grandTotalAll),
    options: {
      fill: { color: "F3E8C2" },
      bold: true,
      align: "center"
    }
  }
]);

slide.addTable(outstandingRows, {
  x: 0.15,
  y: 3.88,
  w: 6.2,
  h: 2.55,
  colW: [1.4, 0.9, 0.6, 0.9, 0.6, 0.9],
  fontFace: "Calibri",
  fontSize: 10,
  border: {
    type: "solid",
    color: "E5E7EB",
    pt: 1
  },
  valign: "middle",
  autoPage: false
});

  // --------------------
  // BOTTOM RIGHT
  // --------------------

  const criticalTotal =
    severityTable["Critical"].within +
    severityTable["Critical"].outside;

  slide.addShape(pres.ShapeType.rect, {
    x: 6.75,
    y: 3.9,
    w: 6.1,
    h: 2.6,
    line: { color: NAVY, pt: 1.5 },
    fill: { color: "F8FAFC" }
  });

  slide.addText(
    "Highlights",
    {
      x: 7.1,
      y: 4.05,
      w: 2,
      h: 0.3,
      fontSize: 18,
      bold: true,
      color: NAVY
    }
  );


}

// ======================================================
// SLIDE 3
// ======================================================
{
  const slide = pres.addSlide();
  slide.background = { color: WHITE };

  // TOP LEFT

  slide.addText(
    `Critical Title Closed — ${THIS_MONTH_LABEL} Month`,
    {
      x: 0.15,
      y: 0.1,
      w: 6.1,
      h: 0.3,
      fontSize: 14,
      bold: true,
      color: NAVY
    }
  );

  slide.addChart(
    "bar",
    [{
      name: "Closed",
      labels: p3Closed.map(x => x.titleGroup),
      values: p3Closed.map(x => x.count)
    }],
    {
      x: 0.15,
      y: 0.5,
      w: 6.1,
      h: 2.7,
      chartColors: [CHART_BLUE],
      showValue: true,
      showLegend: false
    }
  );

  // TOP RIGHT

  slide.addText(
    `Critical Title to be Focused — ${THIS_MONTH_LABEL} Month`,
    {
      x: 6.75,
      y: 0.1,
      w: 6.1,
      h: 0.3,
      fontSize: 14,
      bold: true,
      color: NAVY
    }
  );

  slide.addChart(
    "bar",
    [{
      name: "Focus",
      labels: p3ToFocus.map(x => x.titleGroup),
      values: p3ToFocus.map(x => x.count)
    }],
    {
      x: 6.75,
      y: 0.5,
      w: 6.1,
      h: 2.7,
      chartColors: [CHART_BLUE],
      showValue: true,
      showLegend: false
    }
  );

  // BOTTOM LEFT

  slide.addText(
    `Top 5 Vulnerability Title of Month — ${THIS_MONTH_LABEL}`,
    {
      x: 0.15,
      y: 3.4,
      w: 6.1,
      h: 0.3,
      fontSize: 14,
      bold: true,
      color: NAVY
    }
  );

  const top5Titles = p3All.slice(0, 5);

  slide.addTable(
    [
      ["Vulnerability Title", "Count"],
      ...top5Titles.map(x => [x.titleGroup, String(x.count)])
    ],
    {
      x: 0.15,
      y: 3.8,
      w: 6.1,
      h: 2.3,
      fontSize: 12,
      border: {
        pt: 1,
        color: "D1D5DB"
      }
    }
  );

  // BOTTOM RIGHT

  slide.addText(
    `Top 5 Application to be Focused — ${THIS_MONTH_LABEL}`,
    {
      x: 6.75,
      y: 3.4,
      w: 6.1,
      h: 0.3,
      fontSize: 14,
      bold: true,
      color: NAVY
    }
  );

  const top5Apps = p4All.slice(0, 5);

  slide.addTable(
    [
      ["Application", "Count"],
      ...top5Apps.map(x => [x.app, String(x.count)])
    ],
    {
      x: 6.75,
      y: 3.8,
      w: 6.1,
      h: 2.3,
      fontSize: 12,
      border: {
        pt: 1,
        color: "D1D5DB"
      }
    }
  );
}

  const dateStamp = new Date().toISOString().slice(0, 10);
  pres.writeFile({ fileName: `Monthly_Status_Report_${dateStamp}.pptx` }).then(() => {
    if (typeof showToast === "function") showToast(`Monthly Report downloaded (${enriched.length} records processed).`);
  }).catch(err => {
    console.error("Monthly report PPT generation failed:", err);
    if (typeof showToast === "function") showToast("Monthly Report failed to generate — see console for details.", "error");
  });
}
