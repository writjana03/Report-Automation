/* ==========================================================================
   XLSX-LITE
   A minimal, zero-dependency Office Open XML (.xlsx) writer.
   Supports: multiple sheets, header row + string/number cells, column
   widths. Deliberately does NOT depend on SheetJS/any CDN — everything
   needed to build a valid .xlsx (a ZIP of small XML parts) is implemented
   here so report downloads keep working even if all external script CDNs
   are blocked on the network.
   Exposes: window.XlsxLite.download(filename, sheets)
     sheets: [{ name: "Sheet1", headers: ["A","B"], rows: [["x",1], ...] }]
   ========================================================================== */
(function () {
  "use strict";

  /* ---------------- small binary helpers ---------------- */
  function u16(n) { return [n & 0xff, (n >> 8) & 0xff]; }
  function u32(n) { return [n & 0xff, (n >> 8) & 0xff, (n >> 16) & 0xff, (n >>> 24) & 0xff]; }
  function strBytes(s) { return Array.from(new TextEncoder().encode(s)); }

  /* ---------------- CRC32 (standard table-based) ---------------- */
  var CRC_TABLE = (function () {
    var table = new Uint32Array(256);
    for (var n = 0; n < 256; n++) {
      var c = n;
      for (var k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      table[n] = c >>> 0;
    }
    return table;
  })();
  function crc32(bytes) {
    var crc = 0xFFFFFFFF;
    for (var i = 0; i < bytes.length; i++) {
      crc = CRC_TABLE[(crc ^ bytes[i]) & 0xff] ^ (crc >>> 8);
    }
    return (crc ^ 0xFFFFFFFF) >>> 0;
  }

  /* ---------------- minimal ZIP (store / uncompressed) ---------------- */
  function buildZip(files) {
    // files: [{ name: "path/in/zip.xml", data: Uint8Array }]
    var localParts = [];
    var centralParts = [];
    var offset = 0;

    files.forEach(function (f) {
      var nameBytes = strBytes(f.name);
      var data = f.data;
      var crc = crc32(data);
      var size = data.length;

      var localHeader = []
        .concat(u32(0x04034b50))   // local file header signature
        .concat(u16(20))           // version needed
        .concat(u16(0))            // flags
        .concat(u16(0))            // compression method: 0 = store
        .concat(u16(0))            // mod time
        .concat(u16(0))            // mod date
        .concat(u32(crc))
        .concat(u32(size))         // compressed size == uncompressed (store)
        .concat(u32(size))
        .concat(u16(nameBytes.length))
        .concat(u16(0))            // extra field length
        .concat(nameBytes);

      var localHeaderOffset = offset;
      localParts.push(new Uint8Array(localHeader));
      localParts.push(data);
      offset += localHeader.length + data.length;

      var centralHeader = []
        .concat(u32(0x02014b50))   // central directory signature
        .concat(u16(20))           // version made by
        .concat(u16(20))           // version needed
        .concat(u16(0))            // flags
        .concat(u16(0))            // compression method
        .concat(u16(0))            // mod time
        .concat(u16(0))            // mod date
        .concat(u32(crc))
        .concat(u32(size))
        .concat(u32(size))
        .concat(u16(nameBytes.length))
        .concat(u16(0))            // extra length
        .concat(u16(0))            // comment length
        .concat(u16(0))            // disk number start
        .concat(u16(0))            // internal attrs
        .concat(u32(0))            // external attrs
        .concat(u32(localHeaderOffset))
        .concat(nameBytes);
      centralParts.push(new Uint8Array(centralHeader));
    });

    var centralStart = offset;
    var centralSize = centralParts.reduce(function (sum, p) { return sum + p.length; }, 0);

    var eocd = []
      .concat(u32(0x06054b50))   // end of central directory signature
      .concat(u16(0))            // disk number
      .concat(u16(0))            // disk with central dir
      .concat(u16(files.length)) // entries on this disk
      .concat(u16(files.length)) // total entries
      .concat(u32(centralSize))
      .concat(u32(centralStart))
      .concat(u16(0));           // comment length

    var totalSize = offset + centralSize + eocd.length;
    var out = new Uint8Array(totalSize);
    var pos = 0;
    localParts.concat(centralParts).concat([new Uint8Array(eocd)]).forEach(function (part) {
      out.set(part, pos);
      pos += part.length;
    });
    return out;
  }

  /* ---------------- XML escaping ---------------- */
  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&apos;");
  }

  function colName(idx) {
    // 0 -> A, 1 -> B, ... 26 -> AA
    var s = "";
    idx += 1;
    while (idx > 0) {
      var rem = (idx - 1) % 26;
      s = String.fromCharCode(65 + rem) + s;
      idx = Math.floor((idx - 1) / 26);
    }
    return s;
  }

  function cellXml(colIdx, rowIdx, value, styleIdx) {
    var ref = colName(colIdx) + rowIdx;
    var sAttr = styleIdx ? ' s="' + styleIdx + '"' : "";
    if (typeof value === "number" && isFinite(value)) {
      return '<c r="' + ref + '"' + sAttr + "><v>" + value + "</v></c>";
    }
    if (value === undefined || value === null || value === "") {
      return sAttr ? '<c r="' + ref + '"' + sAttr + "/>" : "";
    }
    return '<c r="' + ref + '"' + sAttr + ' t="inlineStr"><is><t xml:space="preserve">' + esc(value) + "</t></is></c>";
  }

  function lineCount(v) {
    return String(v == null ? "" : v).split("\n").length;
  }
  var LINE_HEIGHT = 15; // Excel's default single-line row height, in points

  /* ---------------- simple (headers + rows) sheet — always style index 0 ---------------- */
  function simpleSheetXml(sheet) {
    var headers = sheet.headers || [];
    var rows = sheet.rows || [];
    var colCount = headers.length;

    var colsXml = "";
    if (sheet.colWidths && sheet.colWidths.length) {
      colsXml = "<cols>" + sheet.colWidths.map(function (w, i) {
        return '<col min="' + (i + 1) + '" max="' + (i + 1) + '" width="' + w + '" customWidth="1"/>';
      }).join("") + "</cols>";
    }

    var rowsXml = "";
    var r = 1;
    function rowAttrs(values) {
      var maxLines = Math.max.apply(null, [1].concat(values.map(lineCount)));
      return maxLines > 1 ? ' ht="' + (maxLines * LINE_HEIGHT) + '" customHeight="1"' : "";
    }

    if (colCount) {
      rowsXml += '<row r="' + r + '"' + rowAttrs(headers) + '>' + headers.map(function (h, i) { return cellXml(i, r, h, 0); }).join("") + "</row>";
      r++;
    }
    rows.forEach(function (row) {
      rowsXml += '<row r="' + r + '"' + rowAttrs(row) + '>' + row.map(function (v, i) { return cellXml(i, r, v, 0); }).join("") + "</row>";
      r++;
    });

    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
      colsXml +
      "<sheetData>" + rowsXml + "</sheetData>" +
      "</worksheet>";
  }

  /* ---------------- grid (explicit cells + merges + styles) sheet ---------------- */
  function styleSignature(st) {
    st = st || {};
    return [st.fill || "", st.bold ? 1 : 0, st.align || "", st.valign || "top",
      st.fontColor || "", st.wrap === false ? 0 : 1, st.fontSize || 11].join("|");
  }

  function gridSheetXml(sheet, resolveStyle) {
    var cells = sheet.cells || [];
    var colsXml = "";
    if (sheet.colWidths && sheet.colWidths.length) {
      colsXml = "<cols>" + sheet.colWidths.map(function (w, i) {
        return '<col min="' + (i + 1) + '" max="' + (i + 1) + '" width="' + w + '" customWidth="1"/>';
      }).join("") + "</cols>";
    }

    // group cells by row
    var byRow = {};
    var maxRow = 0, maxCol = 0;
    cells.forEach(function (c) {
      var m = /^([A-Z]+)(\d+)$/.exec(c.ref);
      var colLetters = m[1], rowNum = parseInt(m[2], 10);
      var colIdx = 0;
      for (var i = 0; i < colLetters.length; i++) colIdx = colIdx * 26 + (colLetters.charCodeAt(i) - 64);
      colIdx -= 1;
      maxRow = Math.max(maxRow, rowNum);
      maxCol = Math.max(maxCol, colIdx);
      (byRow[rowNum] = byRow[rowNum] || []).push({ colIdx: colIdx, rowNum: rowNum, value: c.value, styleIdx: resolveStyle(c.style) });
    });
    if (sheet.rowCount) maxRow = Math.max(maxRow, sheet.rowCount);

    var rowsXml = "";
    for (var r = 1; r <= maxRow; r++) {
      var rowCells = (byRow[r] || []).sort(function (a, b) { return a.colIdx - b.colIdx; });
      var explicitHeight = (sheet.rowHeights && sheet.rowHeights[r]) || null;
      var lineHeights = rowCells.map(function (rc) { return lineCount(rc.value); });
      var maxLines = lineHeights.length ? Math.max.apply(null, lineHeights) : 1;
      var height = explicitHeight || (maxLines > 1 ? maxLines * LINE_HEIGHT : null);
      var htAttr = height ? ' ht="' + height + '" customHeight="1"' : "";
      var cellsXml = rowCells.map(function (rc) { return cellXml(rc.colIdx, rc.rowNum, rc.value, rc.styleIdx); }).join("");
      rowsXml += '<row r="' + r + '"' + htAttr + ">" + cellsXml + "</row>";
    }

    var mergeXml = "";
    if (sheet.merges && sheet.merges.length) {
      mergeXml = '<mergeCells count="' + sheet.merges.length + '">' +
        sheet.merges.map(function (m) { return '<mergeCell ref="' + m + '"/>'; }).join("") +
        "</mergeCells>";
    }

    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
      colsXml +
      "<sheetData>" + rowsXml + "</sheetData>" +
      mergeXml +
      "</worksheet>";
  }

  var CONTENT_TYPES_HEAD =
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
    '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
    '<Default Extension="xml" ContentType="application/xml"/>' +
    '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>' +
    '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>';

  var RELS_ROOT =
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
    '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>' +
    "</Relationships>";

  var STYLES_XML_HEAD =
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">';

  var DEFAULT_XF = '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" applyAlignment="1"><alignment wrapText="1" vertical="top"/></xf>';

  function buildStylesXml(styleList) {
    // styleList: ordered array of style descriptor objects (index 0 reserved
    // for the plain default used by simple-mode sheets and unstyled grid cells).
    var fonts = ['<font><sz val="11"/><name val="Calibri"/></font>'];
    var fills = ['<fill><patternFill patternType="none"/></fill>'];
    var xfs = [DEFAULT_XF];

    styleList.forEach(function (st) {
      if (!st) { xfs.push(DEFAULT_XF); return; }
      var fontIdx = 0;
      if (st.bold || st.fontColor || st.fontSize) {
        fonts.push('<font>' +
          (st.bold ? "<b/>" : "") +
          '<sz val="' + (st.fontSize || 11) + '"/>' +
          (st.fontColor ? '<color rgb="' + st.fontColor + '"/>' : "") +
          '<name val="Calibri"/></font>');
        fontIdx = fonts.length - 1;
      }
      var fillIdx = 0;
      if (st.fill) {
        fills.push('<fill><patternFill patternType="solid"><fgColor rgb="' + st.fill + '"/><bgColor rgb="' + st.fill + '"/></patternFill></fill>');
        fillIdx = fills.length - 1;
      }
      var alignAttrs = 'wrapText="' + (st.wrap === false ? 0 : 1) + '" vertical="' + (st.valign || "top") + '"';
      if (st.align) alignAttrs += ' horizontal="' + st.align + '"';
      xfs.push('<xf numFmtId="0" fontId="' + fontIdx + '" fillId="' + fillIdx + '" borderId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment ' + alignAttrs + '/></xf>');
    });

    return STYLES_XML_HEAD +
      '<fonts count="' + fonts.length + '">' + fonts.join("") + "</fonts>" +
      '<fills count="' + fills.length + '">' + fills.join("") + "</fills>" +
      '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>' +
      '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>' +
      '<cellXfs count="' + xfs.length + '">' + xfs.join("") + "</cellXfs>" +
      "</styleSheet>";
  }

  function build(sheets) {
    var n = sheets.length;

    // Collect every distinct style used across all grid-mode sheets and
    // assign each a stable cellXfs index (0 = plain default, reserved).
    var styleIndexBySignature = {};
    var styleList = [];
    function resolveStyle(st) {
      if (!st) return 0;
      var sig = styleSignature(st);
      if (styleIndexBySignature[sig] === undefined) {
        styleList.push(st);
        styleIndexBySignature[sig] = styleList.length; // 1-based; index 0 is the default
      }
      return styleIndexBySignature[sig];
    }
    sheets.forEach(function (s) {
      if (s.cells) s.cells.forEach(function (c) { resolveStyle(c.style); });
    });
    var stylesXml = buildStylesXml(styleList);

    var contentTypes = CONTENT_TYPES_HEAD +
      sheets.map(function (_, i) {
        return '<Override PartName="/xl/worksheets/sheet' + (i + 1) + '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
      }).join("") +
      "</Types>";

    var workbookXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">' +
      "<sheets>" +
      sheets.map(function (s, i) {
        return '<sheet name="' + esc(s.name).slice(0, 31) + '" sheetId="' + (i + 1) + '" r:id="rId' + (i + 1) + '"/>';
      }).join("") +
      "</sheets></workbook>";

    var workbookRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
      sheets.map(function (_, i) {
        return '<Relationship Id="rId' + (i + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' + (i + 1) + '.xml"/>';
      }).join("") +
      '<Relationship Id="rId' + (n + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>' +
      "</Relationships>";

    var files = [
      { name: "[Content_Types].xml", data: new Uint8Array(strBytes(contentTypes)) },
      { name: "_rels/.rels", data: new Uint8Array(strBytes(RELS_ROOT)) },
      { name: "xl/workbook.xml", data: new Uint8Array(strBytes(workbookXml)) },
      { name: "xl/_rels/workbook.xml.rels", data: new Uint8Array(strBytes(workbookRels)) },
      { name: "xl/styles.xml", data: new Uint8Array(strBytes(stylesXml)) }
    ];
    sheets.forEach(function (s, i) {
      var xml = s.cells ? gridSheetXml(s, resolveStyle) : simpleSheetXml(s);
      files.push({ name: "xl/worksheets/sheet" + (i + 1) + ".xml", data: new Uint8Array(strBytes(xml)) });
    });

    return buildZip(files);
  }

  function download(filename, sheets) {
    var bytes = build(sheets);
    var blob = new Blob([bytes], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }

  window.XlsxLite = { build: build, download: download };
})();
