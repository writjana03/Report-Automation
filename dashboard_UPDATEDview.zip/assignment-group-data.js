/* ==========================================================================
   ASSIGNMENT GROUP & ASSIGNEE MOCK DATA
   Mirrors the Assignment Group / Assignee tracker. One application group
   per country (GI-APAC-<COUNTRY>-APP) — previously two per country
   (APP1/APP2), now consolidated into one group that covers all apps for
   that country. Power Automate / API integration will later replace
   loadAssignmentGroups() with a live fetch that returns objects in this
   same shape.
   ========================================================================== */

const RAW_ASSIGNMENT_GROUPS = [
  {
    groupName: "GI-APAC-AU-APP",
    groupType: "Application",
    teamOrCountry: "AU",
    appCountCovered: 13,
    assignees: ["Carol Martinez", "Wei Lim"],
    emailDL: "L2-GI-APAC-AU@company.com"
  },
  {
    groupName: "GI-APAC-SG-APP",
    groupType: "Application",
    teamOrCountry: "SG",
    appCountCovered: 13,
    assignees: ["Michael Jones", "Priya Miller"],
    emailDL: "L2-GI-APAC-SG@company.com"
  },
  {
    groupName: "GI-APAC-MY-APP",
    groupType: "Application",
    teamOrCountry: "MY",
    appCountCovered: 13,
    assignees: ["Timothy Nguyen", "Linda Allen"],
    emailDL: "L2-GI-APAC-MY@company.com"
  },
  {
    groupName: "GI-APAC-TH-APP",
    groupType: "Application",
    teamOrCountry: "TH",
    appCountCovered: 13,
    assignees: ["Margaret Williams", "Barbara Ramirez"],
    emailDL: "L2-GI-APAC-TH@company.com"
  },
  {
    groupName: "GI-APAC-TW-APP",
    groupType: "Application",
    teamOrCountry: "TW",
    appCountCovered: 13,
    assignees: ["Yuki Jones", "Steven Garcia"],
    emailDL: "L2-GI-APAC-TW@company.com"
  },
  {
    groupName: "GI-APAC-CN-APP",
    groupType: "Application",
    teamOrCountry: "CN",
    appCountCovered: 13,
    assignees: ["Tan Brown", "Jessica Anderson"],
    emailDL: "L2-GI-APAC-CN@company.com"
  },
  {
    groupName: "GI-APAC-ID-APP",
    groupType: "Application",
    teamOrCountry: "ID",
    appCountCovered: 13,
    assignees: ["Linda Torres", "Wei Brown"],
    emailDL: "L2-GI-APAC-ID@company.com"
  },
  {
    groupName: "GI-APAC-PH-APP",
    groupType: "Application",
    teamOrCountry: "PH",
    appCountCovered: 13,
    assignees: ["Donald Williams", "Sarah Jackson"],
    emailDL: "L2-GI-APAC-PH@company.com"
  },
  {
    groupName: "GI-APAC-HK-APP",
    groupType: "Application",
    teamOrCountry: "HK",
    appCountCovered: 13,
    assignees: ["Yuki Martinez", "Anand Davis"],
    emailDL: "L2-GI-APAC-HK@company.com"
  },
  {
    groupName: "GI-APAC-VN-APP",
    groupType: "Application",
    teamOrCountry: "VN",
    appCountCovered: 12,
    assignees: ["Michelle Scott", "Lisa Miller"],
    emailDL: "L2-GI-APAC-VN@company.com"
  },
  {
    groupName: "GI-APAC-NZ-APP",
    groupType: "Application",
    teamOrCountry: "NZ",
    appCountCovered: 12,
    assignees: ["Anthony White", "Richard Scott"],
    emailDL: "L2-GI-APAC-NZ@company.com"
  },
  {
    groupName: "GI-APAC-KR-APP",
    groupType: "Application",
    teamOrCountry: "KR",
    appCountCovered: 12,
    assignees: ["William Torres", "Linda Flores"],
    emailDL: "L2-GI-APAC-KR@company.com"
  },
  {
    groupName: "GI-APAC-APAC-APP",
    groupType: "Application",
    teamOrCountry: "APAC",
    appCountCovered: 3,
    assignees: ["Mark Young", "Priya Ramirez"],
    emailDL: "L2-GI-APAC-APAC@company.com"
  },
  {
    groupName: "GI-APAC-WINTEL",
    groupType: "Infrastructure",
    teamOrCountry: "WinTel Team",
    appCountCovered: null,
    assignees: ["Nancy Clark", "Yuki Tan"],
    emailDL: "GI-APAC-WINTEL@company.com"
  },
  {
    groupName: "GI-APAC-L2-MW",
    groupType: "Infrastructure",
    teamOrCountry: "Middleware Team",
    appCountCovered: null,
    assignees: ["Joshua Walker", "Margaret Fernandez"],
    emailDL: "GI-APAC-L2-MW@company.com"
  },
  {
    groupName: "GI-APAC-NETWORK",
    groupType: "Infrastructure",
    teamOrCountry: "Network Team",
    appCountCovered: null,
    assignees: ["Lee Osman", "Somchai Lopez"],
    emailDL: "GI-APAC-NETWORK@company.com"
  },
  {
    groupName: "GI-APAC-L2-WS",
    groupType: "Infrastructure",
    teamOrCountry: "Web Services Team",
    appCountCovered: null,
    assignees: ["Nguyen King", "Steven Fernandez"],
    emailDL: "GI-APAC-L2-WS@company.com"
  },
  {
    groupName: "GI-APAC-SRT",
    groupType: "Other",
    teamOrCountry: "SRT Team",
    appCountCovered: null,
    assignees: ["James Smith", "Deborah Cordero"],
    emailDL: "GI-APAC-SRT@company.com"
  },
  {
    groupName: "GI-APAC-ISO",
    groupType: "Other",
    teamOrCountry: "ISO Team",
    appCountCovered: null,
    assignees: ["Olivia Ramirez", "William Martinez"],
    emailDL: "GI-APAC-ISO@company.com"
  },
  {
    groupName: "GI-APAC-VULN-MGMT",
    groupType: "Other",
    teamOrCountry: "Vulnerability Management Team",
    appCountCovered: null,
    assignees: ["Sandra Mendoza", "Sandra Ng", "Jennifer Ramirez", "Hiro Flores"],
    emailDL: "GI-APAC-VULN-MGMT@company.com"
  },
  {
    groupName: "GI-APAC-ODR",
    groupType: "Other",
    teamOrCountry: "ODR Team",
    appCountCovered: null,
    assignees: ["Nur Williams", "Brian Wright"],
    emailDL: "GI-APAC-ODR@company.com"
  },
  {
    groupName: "GI-APAC-EPM",
    groupType: "Other",
    teamOrCountry: "EPM Team",
    appCountCovered: null,
    assignees: ["Tran Ng", "Joseph Lim"],
    emailDL: "GI-APAC-EPM@company.com"
  },
  {
    groupName: "GI-APAC-PATCH-OPS",
    groupType: "Other",
    teamOrCountry: "Patching Ops Team",
    appCountCovered: null,
    assignees: ["Deborah Johnson", "Karen Choi"],
    emailDL: "GI-APAC-PATCH-OPS@company.com"
  },
  {
    groupName: "GI-APAC-PATCH-AUTO",
    groupType: "Other",
    teamOrCountry: "Patching Automation Team",
    appCountCovered: null,
    assignees: ["Barbara Davis", "John Robinson"],
    emailDL: "GI-APAC-PATCH-AUTO@company.com"
  },
  {
    groupName: "GI-APAC-CLOUD-SVC",
    groupType: "Other",
    teamOrCountry: "Public Cloud Services Team",
    appCountCovered: null,
    assignees: ["Daniel Scott", "Amanda Sanchez"],
    emailDL: "GI-APAC-CLOUD-SVC@company.com"
  },
  {
    groupName: "GI-APAC-SQL-DBA",
    groupType: "Other",
    teamOrCountry: "SQL IS DBA Team",
    appCountCovered: null,
    assignees: ["Wong Martinez", "Lisa Wong"],
    emailDL: "GI-APAC-SQL-DBA@company.com"
  },
  {
    groupName: "GI-APAC-MSSQL-DBA",
    groupType: "Other",
    teamOrCountry: "MSSQL APP DBA Team",
    appCountCovered: null,
    assignees: ["Robert Walker", "Steven Jones"],
    emailDL: "GI-APAC-MSSQL-DBA@company.com"
  },
  {
    groupName: "GI-APAC-SYBASE-DBA",
    groupType: "Other",
    teamOrCountry: "Sybase DBA Team",
    appCountCovered: null,
    assignees: ["Betty Wilson", "Olivia Park"],
    emailDL: "GI-APAC-SYBASE-DBA@company.com"
  },
  {
    groupName: "GI-APAC-ORACLE-DBA",
    groupType: "Other",
    teamOrCountry: "Oracle DBA Team",
    appCountCovered: null,
    assignees: ["Elizabeth Davis", "Henry Walker"],
    emailDL: "GI-APAC-ORACLE-DBA@company.com"
  },
  {
    groupName: "GI-APAC-UNIX",
    groupType: "Other",
    teamOrCountry: "UNIX Team",
    appCountCovered: null,
    assignees: ["Henry Castillo", "Stephanie Gonzalez"],
    emailDL: "GI-APAC-UNIX@company.com"
  },
];
