/* ==========================================================================
   ASM INVENTORY PAGE
   Self-contained logic for the ASM Inventory register (one Application
   Support Manager per country / region). Reuses shared helpers already
   defined in script.js (escapeHtml, uniqueSorted, formatDate) but keeps its
   own state so it never touches any other page's behavior.
   Coverage counts (apps managed, ADM/Non-ADM split, decom count) are NOT
   stored in the ASM data - they're computed live against RAW_APP_INVENTORY
   at load time, the same way the summary cards on the other pages compute
   their numbers live rather than storing them statically.
   Power Automate / API integration will later replace loadAsmInventory()
   with a live fetch against the master ASM tracker.
   ========================================================================== */

/* ==========================================================================
   STATE
   ========================================================================== */
let asmAllRecords = [];
let asmFilteredRecords = [];
let asmCurrentPage = 1;
let ASM_PAGE_SIZE = 10;
let asmSortState = { key: "country", dir: "asc" };
let asmEditingId = null;
let asmPendingDeleteId = null;

/* ==========================================================================
   DATA LOADING (swap this for a live Power Automate / API call later)
   ========================================================================== */

// Local, self-contained copy of the same parsing logic used in
// app-inventory.js - kept separate on purpose so this page never depends on
// another page's module having run first.
function asmParseCountryFromApplication(applicationName) {
  const parts = String(applicationName).split(" - ");
  return parts[1] ? parts[1].trim() : "Unknown";
}

function asmComputeCoverage(country) {
  const apps = RAW_APP_INVENTORY.filter(a => asmParseCountryFromApplication(a.application) === country);
  const admCount = apps.filter(a => a.admStatus === "ADM").length;
  return {
    appsManaged: apps.length,
    admCount,
    nonAdmCount: apps.length - admCount,
    decomCount: apps.filter(a => a.decomPath === "Yes").length
  };
}

function loadAsmInventory() {
  asmAllRecords = RAW_ASM_INVENTORY.map((r, i) => {
    const coverage = asmComputeCoverage(r.country);
    return {
      id: `asm-${i}`,
      ...r,
      ...coverage
    };
  });
}

/* ==========================================================================
   BADGES
   ========================================================================== */
function asmStatusBadge(status) {
  const map = { Active: "badge-success", Inactive: "badge-neutral", Leave: "badge-warning" };
  const cls = map[status] || "badge-neutral";
  return `<span class="badge-status ${cls}"><span class="dot"></span>${escapeHtml(status)}</span>`;
}

/* ==========================================================================
   FILTER OPTIONS
   ========================================================================== */
function asmRefreshFilterOptions() {
  const configs = [
    { id: "asmFilterCountry", getter: r => r.country },
    { id: "asmFilterStatus", getter: r => r.status }
  ];
  configs.forEach(cfg => {
    const sel = document.getElementById(cfg.id);
    const current = sel.value;
    sel.innerHTML = '<option value="">All</option>';
    uniqueSorted(asmAllRecords.map(cfg.getter)).forEach(v => sel.add(new Option(v, v)));
    if ([...sel.options].some(o => o.value === current)) {
      sel.value = current;
    }
  });
}

/* ==========================================================================
   SUMMARY CARDS
   ========================================================================== */
function asmComputeSummary() {
  const total = asmAllRecords.length;
  const active = asmAllRecords.filter(r => r.status === "Active").length;
  const unavailable = total - active;
  const totalAppsManaged = asmAllRecords.reduce((sum, r) => sum + r.appsManaged, 0);
  return { total, active, unavailable, totalAppsManaged };
}

function asmRenderSummary() {
  const s = asmComputeSummary();
  const grid = document.getElementById("asmSummaryGrid");
  const cards = [
    { cls: "sc-total", icon: "bi-person-badge-fill", value: s.total, label: "Total ASMs", sub: "One per country / region" },
    { cls: "sc-resolved", icon: "bi-person-check-fill", value: s.active, label: "Active ASMs", sub: "Currently reachable" },
    { cls: "sc-pending", icon: "bi-person-dash-fill", value: s.unavailable, label: "On Leave / Inactive", sub: "Route via Team DL" },
    { cls: "sc-feedback", icon: "bi-collection-fill", value: s.totalAppsManaged, label: "Applications Managed", sub: "Across all ASMs (live count)" }
  ];
  grid.innerHTML = cards.map(c => `
    <div class="summary-card ${c.cls}">
      <div class="sc-top"><span class="sc-icon"><i class="bi ${c.icon}"></i></span></div>
      <div class="sc-value">${c.value}</div>
      <div class="sc-label">${c.label}</div>
      <div class="sc-sublabel">${c.sub}</div>
    </div>
  `).join("");
}

/* ==========================================================================
   FILTER + SEARCH + SORT PIPELINE
   ========================================================================== */
function asmApplyFilters() {
  const q = document.getElementById("asmSearchInput").value.trim().toLowerCase();
  const country = document.getElementById("asmFilterCountry").value;
  const status = document.getElementById("asmFilterStatus").value;

  asmFilteredRecords = asmAllRecords.filter(r => {
    if (country && r.country !== country) return false;
    if (status && r.status !== status) return false;

    if (q) {
      const haystack = [r.asmName, r.asmEmail, r.country, r.teamDL, r.notes].join(" ").toLowerCase();
      if (!haystack.includes(q)) return false;
    }
    return true;
  });

  asmSortRecords();
  asmRenderTable();
}

function asmSortRecords() {
  const { key, dir } = asmSortState;
  asmFilteredRecords.sort((a, b) => {
    let va = a[key], vb = b[key];
    if (typeof va === "string") va = va.toLowerCase();
    if (typeof vb === "string") vb = vb.toLowerCase();
    if (va < vb) return dir === "asc" ? -1 : 1;
    if (va > vb) return dir === "asc" ? 1 : -1;
    return 0;
  });
}

/* ==========================================================================
   TABLE RENDER
   ========================================================================== */
function asmRenderTable() {
  const body = document.getElementById("asmRecordsBody");
  const empty = document.getElementById("asmEmptyState");
  const countEl = document.getElementById("asmResultsCount");
  const table = document.getElementById("asmRecordsTable");
  const exportBtn = document.getElementById("asmExportBtn");

  countEl.textContent = `${asmFilteredRecords.length} ASM${asmFilteredRecords.length === 1 ? "" : "s"}`;
  exportBtn.disabled = asmFilteredRecords.length === 0;

  if (asmFilteredRecords.length === 0) {
    body.innerHTML = "";
    table.style.display = "none";
    empty.classList.remove("d-none");
    document.getElementById("asmPaginationBar").style.visibility = "hidden";
    return;
  }
  table.style.display = "table";
  empty.classList.add("d-none");
  document.getElementById("asmPaginationBar").style.visibility = "visible";

  const totalPages = Math.max(1, Math.ceil(asmFilteredRecords.length / ASM_PAGE_SIZE));
  asmCurrentPage = Math.min(asmCurrentPage, totalPages);
  const start = (asmCurrentPage - 1) * ASM_PAGE_SIZE;
  const pageItems = asmFilteredRecords.slice(start, start + ASM_PAGE_SIZE);
  const rangeStart = asmFilteredRecords.length === 0 ? 0 : start + 1;
  const rangeEnd = Math.min(start + ASM_PAGE_SIZE, asmFilteredRecords.length);

  body.innerHTML = pageItems.map(r => `
      <tr>
        <td class="cell-app">
          <span class="app-name">${escapeHtml(r.asmName)}</span>
        </td>
        <td class="cell-date">${escapeHtml(r.country)}</td>
        <td class="cell-date">${escapeHtml(r.asmEmail)}</td>
        <td class="cell-date">${escapeHtml(r.teamDL)}</td>
        <td>${r.appsManaged}</td>
        <td class="cell-owner">
          <span class="owner-name">${r.admCount} ADM</span>
          <span class="owner-role">${r.nonAdmCount} Non-ADM</span>
        </td>
        <td>${r.decomCount}</td>
        <td>${asmStatusBadge(r.status)}</td>
        <td class="cell-date">${formatDate(r.lastVerified)}</td>
        <td class="td-action">
          ${renderActionCell(r.id)}
        </td>
      </tr>
    `).join("");

  body.querySelectorAll(".btn-view-row").forEach(btn => {
    btn.addEventListener("click", () => asmOpenViewModal(btn.dataset.id));
  });
  body.querySelectorAll(".btn-update-row").forEach(btn => {
    btn.addEventListener("click", () => asmOpenEditModal(btn.dataset.id));
  });
  body.querySelectorAll(".btn-delete-row").forEach(btn => {
    btn.addEventListener("click", () => asmOpenDeleteConfirm(btn.dataset.id));
  });

  initActionDropdowns(body);

  document.getElementById("asmPageInfo").textContent =
    `Showing ${rangeStart}-${rangeEnd} of ${asmFilteredRecords.length} results`;

  document.getElementById("asmFirstPage").disabled = asmCurrentPage <= 1;
  document.getElementById("asmPrevPage").disabled = asmCurrentPage <= 1;
  document.getElementById("asmNextPage").disabled = asmCurrentPage >= totalPages;
  document.getElementById("asmLastPage").disabled = asmCurrentPage >= totalPages;

  const pageJumpInput = document.getElementById("asmPageJumpInput");
  pageJumpInput.max = String(totalPages);
  if (document.activeElement !== pageJumpInput) {
    pageJumpInput.value = String(asmCurrentPage);
  }
  document.getElementById("asmPageJumpTotal").textContent = `of ${totalPages}`;

  document.querySelectorAll("#asmRecordsTable thead th[data-sort]").forEach(th => {
    th.querySelector(".sort-caret")?.remove();
    if (th.dataset.sort === asmSortState.key) {
      const caret = document.createElement("span");
      caret.className = "sort-caret";
      caret.innerHTML = asmSortState.dir === "asc" ? "\u25B2" : "\u25BC";
      th.appendChild(caret);
    }
  });
}

/* ==========================================================================
   VIEW ASM (read-only)
   ========================================================================== */
function asmOpenViewModal(id) {
  const r = asmAllRecords.find(x => x.id === id);
  if (!r) return;

  document.getElementById("viewAsmCountry").textContent = r.country;
  document.getElementById("viewAsmTitle").textContent = r.asmName;

  document.getElementById("viewAsmBody").innerHTML = `
    <div class="detail-section-title">Contact</div>
    <div class="detail-grid">
      <div class="detail-item">
        <div class="di-label">ASM Email</div>
        <div class="di-value mono">${escapeHtml(r.asmEmail)}</div>
      </div>
      <div class="detail-item">
        <div class="di-label">Team DL</div>
        <div class="di-value mono">${escapeHtml(r.teamDL)}</div>
      </div>
      <div class="detail-item">
        <div class="di-label">Country / Region</div>
        <div class="di-value">${escapeHtml(r.country)}</div>
      </div>
      <div class="detail-item">
        <div class="di-label">Status</div>
        <div class="di-value">${asmStatusBadge(r.status)}</div>
      </div>
    </div>

    <div class="detail-section-title">Application Coverage (live)</div>
    <div class="detail-grid">
      <div class="detail-item">
        <div class="di-label">Applications Managed</div>
        <div class="di-value">${r.appsManaged}</div>
      </div>
      <div class="detail-item">
        <div class="di-label">ADM / Non-ADM</div>
        <div class="di-value">${r.admCount} ADM &middot; ${r.nonAdmCount} Non-ADM</div>
      </div>
      <div class="detail-item full">
        <div class="di-label">Apps on Decom Path</div>
        <div class="di-value">${r.decomCount}</div>
      </div>
    </div>

    <div class="detail-section-title">Governance</div>
    <div class="detail-grid">
      <div class="detail-item">
        <div class="di-label">Last Verified</div>
        <div class="di-value">${formatDate(r.lastVerified)}</div>
      </div>
      <div class="detail-item full">
        <div class="di-label">Notes</div>
        <div class="di-value">${r.notes ? escapeHtml(r.notes) : "&mdash;"}</div>
      </div>
    </div>
  `;

  const modal = new bootstrap.Modal(document.getElementById("viewAsmModal"));
  modal.show();
}

/* ==========================================================================
   UPDATE ASM
   ========================================================================== */
function asmPopulateEditCountryOptions() {
  const sel = document.getElementById("editAsmCountry");
  if (sel.options.length > 0) return; // populate once
  uniqueSorted(asmAllRecords.map(r => r.country)).forEach(v => sel.add(new Option(v, v)));
}

function asmOpenEditModal(id) {
  const r = asmAllRecords.find(x => x.id === id);
  if (!r) return;
  asmEditingId = id;

  asmPopulateEditCountryOptions();
  document.getElementById("editAsmName").value = r.asmName;
  document.getElementById("editAsmCountry").value = r.country;
  document.getElementById("editAsmEmail").value = r.asmEmail;
  document.getElementById("editAsmTeamDL").value = r.teamDL;
  document.getElementById("editAsmStatus").value = r.status;
  document.getElementById("editAsmLastVerified").value = r.lastVerified;
  document.getElementById("editAsmNotes").value = r.notes || "";

  const modal = new bootstrap.Modal(document.getElementById("editAsmModal"));
  modal.show();
}

function asmHandleEditSubmit(e) {
  e.preventDefault();
  const form = document.getElementById("editAsmForm");
  if (!form.checkValidity()) {
    form.reportValidity();
    return;
  }
  if (!asmEditingId) return;

  const asmName = document.getElementById("editAsmName").value.trim();
  const country = document.getElementById("editAsmCountry").value;
  const asmEmail = document.getElementById("editAsmEmail").value.trim();
  const teamDL = document.getElementById("editAsmTeamDL").value.trim();
  const status = document.getElementById("editAsmStatus").value;
  const lastVerified = document.getElementById("editAsmLastVerified").value;
  const notes = document.getElementById("editAsmNotes").value.trim();

  const idx = asmAllRecords.findIndex(r => r.id === asmEditingId);
  if (idx !== -1) {
    // Country changed -> recompute this ASM's live application coverage for
    // the newly assigned country.
    const coverage = asmComputeCoverage(country);
    asmAllRecords[idx] = {
      ...asmAllRecords[idx],
      asmName, country, asmEmail, teamDL, status, lastVerified, notes,
      ...coverage
    };
  }
  asmEditingId = null;
  showToast("ASM record updated.");

  asmRefreshFilterOptions();
  asmRenderSummary();
  asmApplyFilters();

  const modalEl = document.getElementById("editAsmModal");
  bootstrap.Modal.getInstance(modalEl)?.hide();
}

/* ==========================================================================
   DELETE ASM
   ========================================================================== */
function asmOpenDeleteConfirm(id) {
  const r = asmAllRecords.find(x => x.id === id);
  if (!r) return;
  asmPendingDeleteId = id;
  document.getElementById("deleteAsmName").textContent = r.asmName;
  const modal = new bootstrap.Modal(document.getElementById("deleteAsmModal"));
  modal.show();
}

function asmConfirmDelete() {
  if (!asmPendingDeleteId) return;
  asmAllRecords = asmAllRecords.filter(r => r.id !== asmPendingDeleteId);
  asmPendingDeleteId = null;

  asmRefreshFilterOptions();
  asmRenderSummary();
  asmCurrentPage = 1;
  asmApplyFilters();
  showToast("ASM record deleted.");

  const modalEl = document.getElementById("deleteAsmModal");
  bootstrap.Modal.getInstance(modalEl)?.hide();
}

/* ==========================================================================
   EXPORT (exports all currently filtered ASMs to an Excel file)
   ========================================================================== */
const ASM_EXPORT_COLUMNS = [
  { header: "ASM Name", key: "asmName" },
  { header: "Country / Region", key: "country" },
  { header: "ASM Email", key: "asmEmail" },
  { header: "Team DL", key: "teamDL" },
  { header: "Applications Managed", key: "appsManaged" },
  { header: "ADM Count", key: "admCount" },
  { header: "Non-ADM Count", key: "nonAdmCount" },
  { header: "Decom Path Apps", key: "decomCount" },
  { header: "Status", key: "status" },
  { header: "Last Verified", key: "lastVerified" },
  { header: "Notes", key: "notes" }
];

function asmDownloadAllRecords() {
  if (!asmFilteredRecords.length) return;

  const rows = asmFilteredRecords.map(r => {
    const row = {};
    ASM_EXPORT_COLUMNS.forEach(col => {
      const raw = r[col.key];
      row[col.header] = (raw === undefined || raw === null || raw === "") ? "\u2014" : raw;
    });
    return row;
  });

  const worksheet = XLSX.utils.json_to_sheet(rows, { header: ASM_EXPORT_COLUMNS.map(c => c.header) });
  worksheet["!cols"] = ASM_EXPORT_COLUMNS.map(c => ({ wch: Math.max(12, Math.min(42, c.header.length + 6)) }));

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "ASM Inventory");

  const dateStamp = new Date().toISOString().slice(0, 10);
  XLSX.writeFile(workbook, `asm_inventory_export_${asmFilteredRecords.length}records_${dateStamp}.xlsx`);
}

/* ==========================================================================
   EVENTS
   ========================================================================== */
function asmWireEvents() {
  const searchInput = document.getElementById("asmSearchInput");
  const searchClear = document.getElementById("asmSearchClear");

  searchInput.addEventListener("input", () => {
    searchClear.classList.toggle("d-none", searchInput.value.length === 0);
    asmCurrentPage = 1;
    asmApplyFilters();
  });
  searchClear.addEventListener("click", () => {
    searchInput.value = "";
    searchClear.classList.add("d-none");
    asmCurrentPage = 1;
    asmApplyFilters();
  });

  const ASM_FILTER_IDS = ["asmFilterCountry", "asmFilterStatus"];
  ASM_FILTER_IDS.forEach(id => {
    document.getElementById(id).addEventListener("change", () => {
      asmCurrentPage = 1;
      asmApplyFilters();
    });
  });

  const asmResetFilters = () => {
    ASM_FILTER_IDS.forEach(id => { document.getElementById(id).value = ""; });
    searchInput.value = "";
    searchClear.classList.add("d-none");
    asmCurrentPage = 1;
    asmApplyFilters();
  };
  document.getElementById("asmResetFiltersBtn").addEventListener("click", asmResetFilters);
  document.getElementById("asmEmptyResetBtn").addEventListener("click", asmResetFilters);

  document.querySelectorAll("#asmRecordsTable thead th[data-sort]").forEach(th => {
    th.addEventListener("click", () => {
      const key = th.dataset.sort;
      if (asmSortState.key === key) {
        asmSortState.dir = asmSortState.dir === "asc" ? "desc" : "asc";
      } else {
        asmSortState = { key, dir: "asc" };
      }
      asmSortRecords();
      asmRenderTable();
    });
  });

  document.getElementById("asmFirstPage").addEventListener("click", () => {
    if (asmCurrentPage > 1) { asmCurrentPage = 1; asmRenderTable(); }
  });
  document.getElementById("asmPrevPage").addEventListener("click", () => {
    if (asmCurrentPage > 1) { asmCurrentPage--; asmRenderTable(); }
  });
  document.getElementById("asmNextPage").addEventListener("click", () => {
    asmCurrentPage++; asmRenderTable();
  });
  document.getElementById("asmLastPage").addEventListener("click", () => {
    const totalPages = Math.max(1, Math.ceil(asmFilteredRecords.length / ASM_PAGE_SIZE));
    if (asmCurrentPage < totalPages) { asmCurrentPage = totalPages; asmRenderTable(); }
  });

  const pageJumpInput = document.getElementById("asmPageJumpInput");
  const goToTypedPage = () => {
    const totalPages = Math.max(1, Math.ceil(asmFilteredRecords.length / ASM_PAGE_SIZE));
    let target = parseInt(pageJumpInput.value, 10);
    if (!Number.isFinite(target)) target = asmCurrentPage;
    target = Math.min(Math.max(target, 1), totalPages);
    asmCurrentPage = target;
    asmRenderTable();
  };
  pageJumpInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      goToTypedPage();
      pageJumpInput.blur();
    }
  });
  pageJumpInput.addEventListener("blur", () => {
    pageJumpInput.value = String(asmCurrentPage);
  });

  const pageSizeSelect = document.getElementById("asmPageSizeSelect");
  pageSizeSelect.value = String(ASM_PAGE_SIZE);
  pageSizeSelect.addEventListener("change", (e) => {
    ASM_PAGE_SIZE = parseInt(e.target.value, 10);
    asmCurrentPage = 1;
    asmRenderTable();
  });

  document.getElementById("asmExportBtn").addEventListener("click", () => {
    asmDownloadAllRecords();
  });

  document.getElementById("editAsmForm").addEventListener("submit", asmHandleEditSubmit);
  document.getElementById("confirmDeleteAsmBtn").addEventListener("click", asmConfirmDelete);
}

/* ==========================================================================
   INIT
   ========================================================================== */
document.addEventListener("DOMContentLoaded", () => {
  loadAsmInventory();
  asmRefreshFilterOptions();
  asmRenderSummary();
  asmWireEvents();
  asmApplyFilters();
});
