/* ==========================================================================
   APPLICATION INVENTORY PAGE
   Self-contained logic for the Application Inventory tab. Reuses shared
   helpers already defined in script.js (escapeHtml, uniqueSorted) but keeps
   its own state so it never touches the Vulnerabilities page's behavior.
   Power Automate / API integration will later replace loadAppInventory()
   and the add/delete handlers with live calls against the master tracker.
   ========================================================================== */

const APP_COUNTRY_LIST = ["AU", "SG", "MY", "TH", "TW", "CN", "ID", "PH", "HK", "VN", "NZ", "KR", "APAC"];

/* ==========================================================================
   STATE
   ========================================================================== */
let appAllRecords = [];
let appFilteredRecords = [];
let appCurrentPage = 1;
let APP_PAGE_SIZE = 10;
let appSortState = { key: "application", dir: "asc" };
let appNextSeq = 1;
let appPendingDeleteId = null;
let appEditingId = null; // set while the Add/Update modal is editing an existing record

/* ==========================================================================
   DATA LOADING (swap this for a live Power Automate / API call later)
   ========================================================================== */
function parseApplicationParts(applicationName) {
  const parts = String(applicationName).split(" - ");
  return {
    gearId: parts[0] ? parts[0].trim() : "",
    country: parts[1] ? parts[1].trim() : "Unknown",
    name: parts.slice(2).join(" - ").trim()
  };
}

function loadAppInventory() {
  appAllRecords = RAW_APP_INVENTORY.map((r, i) => {
    const parts = parseApplicationParts(r.application);
    return {
      id: `app-${i}`,
      country: parts.country,
      appName: parts.name,
      ...r
    };
  });
  appNextSeq = appAllRecords.length + 1;
}

/* ==========================================================================
   BADGES
   ========================================================================== */
function admBadge(status) {
  const cls = status === "ADM" ? "badge-info" : "badge-neutral";
  return `<span class="badge-status ${cls}"><span class="dot"></span>${escapeHtml(status)}</span>`;
}
function decomBadge(value) {
  const cls = value === "Yes" ? "badge-warning" : "badge-success";
  return `<span class="badge-status ${cls}"><span class="dot"></span>${escapeHtml(value)}</span>`;
}

/* ==========================================================================
   FILTER OPTIONS
   ========================================================================== */
function appRefreshFilterOptions() {
  const configs = [
    { id: "appFilterCountry", getter: r => r.country },
    { id: "appFilterAdm", getter: r => r.admStatus },
    { id: "appFilterDecom", getter: r => r.decomPath },
    { id: "appFilterAsm", getter: r => r.asmName },
    { id: "appFilterOwner", getter: r => r.appOwner },
    { id: "appFilterEscalation", getter: r => r.escalationPoint }
  ];
  configs.forEach(cfg => {
    const sel = document.getElementById(cfg.id);
    const current = sel.value;
    sel.innerHTML = '<option value="">All</option>';
    uniqueSorted(appAllRecords.map(cfg.getter)).forEach(v => sel.add(new Option(v, v)));
    if ([...sel.options].some(o => o.value === current)) {
      sel.value = current;
    }
  });
}

function appPopulateAddCountryOptions() {
  const sel = document.getElementById("addCountry");
  APP_COUNTRY_LIST.forEach(c => sel.add(new Option(c, c)));
}

/* ==========================================================================
   SUMMARY CARDS
   ========================================================================== */
function appComputeSummary() {
  const total = appAllRecords.length;
  const adm = appAllRecords.filter(r => r.admStatus === "ADM").length;
  const nonAdm = total - adm;
  const decomYes = appAllRecords.filter(r => r.decomPath === "Yes").length;
  return { total, adm, nonAdm, decomYes };
}

function appRenderSummary() {
  const s = appComputeSummary();
  const grid = document.getElementById("appSummaryGrid");
  const cards = [
    { cls: "sc-total", icon: "bi-collection", value: s.total, label: "Total Applications" },
    { cls: "sc-resolved", icon: "bi-diagram-3", value: s.adm, label: "ADM Applications" },
    { cls: "sc-feedback", icon: "bi-diagram-2", value: s.nonAdm, label: "Non-ADM Applications" },
    { cls: "sc-pending", icon: "bi-signpost-split", value: s.decomYes, label: "On Decom Path" }
  ];
  grid.innerHTML = cards.map(c => `
    <div class="summary-card ${c.cls}">
      <div class="sc-top"><span class="sc-icon"><i class="bi ${c.icon}"></i></span></div>
      <div class="sc-value">${c.value}</div>
      <div class="sc-label">${c.label}</div>
    </div>
  `).join("");
}

/* ==========================================================================
   FILTER + SEARCH + SORT PIPELINE
   ========================================================================== */
function appApplyFilters() {
  const q = document.getElementById("appSearchInput").value.trim().toLowerCase();
  const country = document.getElementById("appFilterCountry").value;
  const adm = document.getElementById("appFilterAdm").value;
  const decom = document.getElementById("appFilterDecom").value;
  const asm = document.getElementById("appFilterAsm").value;
  const owner = document.getElementById("appFilterOwner").value;
  const esc = document.getElementById("appFilterEscalation").value;

  appFilteredRecords = appAllRecords.filter(r => {
    if (country && r.country !== country) return false;
    if (adm && r.admStatus !== adm) return false;
    if (decom && r.decomPath !== decom) return false;
    if (asm && r.asmName !== asm) return false;
    if (owner && r.appOwner !== owner) return false;
    if (esc && r.escalationPoint !== esc) return false;

    if (q) {
      const haystack = [
        r.application, r.gearId, r.country, r.appOwner, r.appOwnerEmail,
        r.escalationPoint, r.escalationPointEmail, r.asmName, r.asmEmail,
        r.admStatus, r.decomPath
      ].join(" ").toLowerCase();
      if (!haystack.includes(q)) return false;
    }
    return true;
  });

  appSortRecords();
  appRenderTable();
}

function appSortRecords() {
  const { key, dir } = appSortState;
  appFilteredRecords.sort((a, b) => {
    let va = a[key], vb = b[key];
    if (typeof va === "string") va = va.toLowerCase();
    if (typeof vb === "string") vb = vb.toLowerCase();
    if (va < vb) return dir === "asc" ? -1 : 1;
    if (va > vb) return dir === "asc" ? 1 : -1;
    return 0;
  });
}

/* ==========================================================================
   TABLE RENDER
   ========================================================================== */
function appRenderTable() {
  const body = document.getElementById("appRecordsBody");
  const empty = document.getElementById("appEmptyState");
  const countEl = document.getElementById("appResultsCount");
  const table = document.getElementById("appRecordsTable");
  const exportBtn = document.getElementById("appExportBtn");

  countEl.textContent = `${appFilteredRecords.length} application${appFilteredRecords.length === 1 ? "" : "s"}`;
  exportBtn.disabled = appFilteredRecords.length === 0;

  if (appFilteredRecords.length === 0) {
    body.innerHTML = "";
    table.style.display = "none";
    empty.classList.remove("d-none");
    document.getElementById("appPaginationBar").style.visibility = "hidden";
    return;
  }
  table.style.display = "table";
  empty.classList.add("d-none");
  document.getElementById("appPaginationBar").style.visibility = "visible";

  const totalPages = Math.max(1, Math.ceil(appFilteredRecords.length / APP_PAGE_SIZE));
  appCurrentPage = Math.min(appCurrentPage, totalPages);
  const start = (appCurrentPage - 1) * APP_PAGE_SIZE;
  const pageItems = appFilteredRecords.slice(start, start + APP_PAGE_SIZE);
  const rangeStart = appFilteredRecords.length === 0 ? 0 : start + 1;
  const rangeEnd = Math.min(start + APP_PAGE_SIZE, appFilteredRecords.length);

  body.innerHTML = pageItems.map(r => `
      <tr>
        <td class="cell-app">
          <span class="app-name">${escapeHtml(r.application)}</span>
          <span class="app-sub">Gear ID ${escapeHtml(r.gearId)} &middot; ${escapeHtml(r.country)}</span>
        </td>
        <td>${admBadge(r.admStatus)}</td>
        <td>${decomBadge(r.decomPath)}</td>
        <td class="cell-owner">
          <span class="owner-name">${escapeHtml(r.appOwner)}</span>
          <span class="owner-role">${escapeHtml(r.appOwnerEmail)}</span>
        </td>
        <td class="cell-owner">
          <span class="owner-name">${escapeHtml(r.escalationPoint)}</span>
          <span class="owner-role">${escapeHtml(r.escalationPointEmail)}</span>
        </td>
        <td class="cell-owner">
          <span class="owner-name">${escapeHtml(r.asmName)}</span>
          <span class="owner-role">${escapeHtml(r.asmEmail)}</span>
        </td>
        <td class="td-action">
          <div class="action-buttons">
            <button class="btn-view-row" data-id="${r.id}" title="View full details"><i class="bi bi-eye"></i> View</button>
            <button class="btn-update-row" data-id="${r.id}" title="Update this application"><i class="bi bi-pencil"></i> Update</button>
            <button class="btn-delete-row" data-id="${r.id}" title="Delete this application"><i class="bi bi-trash3"></i> Delete</button>
          </div>
        </td>
      </tr>
    `).join("");

  body.querySelectorAll(".btn-view-row").forEach(btn => {
    btn.addEventListener("click", () => appOpenViewModal(btn.dataset.id));
  });
  body.querySelectorAll(".btn-update-row").forEach(btn => {
    btn.addEventListener("click", () => appOpenEditModal(btn.dataset.id));
  });
  body.querySelectorAll(".btn-delete-row").forEach(btn => {
    btn.addEventListener("click", () => appOpenDeleteConfirm(btn.dataset.id));
  });

  document.getElementById("appPageInfo").textContent =
    `Showing ${rangeStart}-${rangeEnd} of ${appFilteredRecords.length} results`;

  document.getElementById("appFirstPage").disabled = appCurrentPage <= 1;
  document.getElementById("appPrevPage").disabled = appCurrentPage <= 1;
  document.getElementById("appNextPage").disabled = appCurrentPage >= totalPages;
  document.getElementById("appLastPage").disabled = appCurrentPage >= totalPages;

  const pageJumpInput = document.getElementById("appPageJumpInput");
  pageJumpInput.max = String(totalPages);
  if (document.activeElement !== pageJumpInput) {
    pageJumpInput.value = String(appCurrentPage);
  }
  document.getElementById("appPageJumpTotal").textContent = `of ${totalPages}`;

  document.querySelectorAll("#appRecordsTable thead th[data-sort]").forEach(th => {
    th.querySelector(".sort-caret")?.remove();
    if (th.dataset.sort === appSortState.key) {
      const caret = document.createElement("span");
      caret.className = "sort-caret";
      caret.innerHTML = appSortState.dir === "asc" ? "\u25B2" : "\u25BC";
      th.appendChild(caret);
    }
  });
}

/* ==========================================================================
   ADD / UPDATE APPLICATION (same modal, toggled by appEditingId)
   ========================================================================== */
function appOpenAddModal() {
  appEditingId = null;
  document.getElementById("addAppForm").reset();
  document.getElementById("addAppModalEyebrow").textContent = "New Record";
  document.getElementById("addAppModalTitle").textContent = "Add Application";
  document.getElementById("addAppSubmitBtn").textContent = "Add Application";
  const modal = new bootstrap.Modal(document.getElementById("addAppModal"));
  modal.show();
}

function appOpenEditModal(id) {
  const r = appAllRecords.find(x => x.id === id);
  if (!r) return;
  appEditingId = id;

  document.getElementById("addGearId").value = r.gearId;
  document.getElementById("addCountry").value = r.country;
  document.getElementById("addAppName").value = r.appName;
  document.getElementById("addAdm").value = r.admStatus;
  document.getElementById("addDecom").value = r.decomPath;
  document.getElementById("addOwnerName").value = r.appOwner;
  document.getElementById("addOwnerEmail").value = r.appOwnerEmail;
  document.getElementById("addEscName").value = r.escalationPoint;
  document.getElementById("addEscEmail").value = r.escalationPointEmail;
  document.getElementById("addAsmName").value = r.asmName;
  document.getElementById("addAsmEmail").value = r.asmEmail;

  document.getElementById("addAppModalEyebrow").textContent = "Edit Record";
  document.getElementById("addAppModalTitle").textContent = "Update Application";
  document.getElementById("addAppSubmitBtn").textContent = "Save Changes";
  const modal = new bootstrap.Modal(document.getElementById("addAppModal"));
  modal.show();
}

function appHandleAddSubmit(e) {
  e.preventDefault();
  const form = document.getElementById("addAppForm");
  if (!form.checkValidity()) {
    form.reportValidity();
    return;
  }

  const gearId = document.getElementById("addGearId").value.trim();
  const country = document.getElementById("addCountry").value;
  const name = document.getElementById("addAppName").value.trim();
  const admStatus = document.getElementById("addAdm").value;
  const decomPath = document.getElementById("addDecom").value;
  const appOwner = document.getElementById("addOwnerName").value.trim();
  const appOwnerEmail = document.getElementById("addOwnerEmail").value.trim();
  const escalationPoint = document.getElementById("addEscName").value.trim();
  const escalationPointEmail = document.getElementById("addEscEmail").value.trim();
  const asmName = document.getElementById("addAsmName").value.trim();
  const asmEmail = document.getElementById("addAsmEmail").value.trim();

  const application = `${gearId} - ${country} - ${name}`;

  if (appEditingId) {
    const idx = appAllRecords.findIndex(r => r.id === appEditingId);
    if (idx !== -1) {
      appAllRecords[idx] = {
        ...appAllRecords[idx],
        application, country, appName: name, gearId, admStatus, decomPath,
        appOwner, appOwnerEmail, escalationPoint, escalationPointEmail, asmName, asmEmail
      };
    }
    appEditingId = null;
    showToast("Application updated.");
  } else {
    const newRecord = {
      id: `app-new-${appNextSeq++}`,
      application, country, appName: name, gearId, admStatus, decomPath,
      appOwner, appOwnerEmail, escalationPoint, escalationPointEmail, asmName, asmEmail
    };
    appAllRecords.unshift(newRecord);
    showToast("Application added.");
  }

  appRefreshFilterOptions();
  appRenderSummary();
  appCurrentPage = 1;
  appApplyFilters();

  const modalEl = document.getElementById("addAppModal");
  bootstrap.Modal.getInstance(modalEl)?.hide();
}

/* ==========================================================================
   VIEW APPLICATION (read-only)
   ========================================================================== */
function appOpenViewModal(id) {
  const r = appAllRecords.find(x => x.id === id);
  if (!r) return;

  document.getElementById("viewAppGearId").textContent = `Gear ID ${r.gearId}`;
  document.getElementById("viewAppTitle").textContent = r.application;

  document.getElementById("viewAppBody").innerHTML = `
    <div class="detail-section-title">Application</div>
    <div class="detail-grid">
      <div class="detail-item">
        <div class="di-label">Gear ID</div>
        <div class="di-value mono">${escapeHtml(r.gearId)}</div>
      </div>
      <div class="detail-item">
        <div class="di-label">Country</div>
        <div class="di-value">${escapeHtml(r.country)}</div>
      </div>
      <div class="detail-item full">
        <div class="di-label">Application Name</div>
        <div class="di-value">${escapeHtml(r.appName)}</div>
      </div>
      <div class="detail-item">
        <div class="di-label">ADM / Non-ADM</div>
        <div class="di-value">${admBadge(r.admStatus)}</div>
      </div>
      <div class="detail-item">
        <div class="di-label">Decom Path</div>
        <div class="di-value">${decomBadge(r.decomPath)}</div>
      </div>
    </div>

    <div class="detail-section-title">Ownership &amp; Escalation</div>
    <div class="detail-grid">
      <div class="detail-item">
        <div class="di-label">App Owner</div>
        <div class="di-value">${escapeHtml(r.appOwner)}</div>
      </div>
      <div class="detail-item">
        <div class="di-label">App Owner Email</div>
        <div class="di-value mono">${escapeHtml(r.appOwnerEmail)}</div>
      </div>
      <div class="detail-item">
        <div class="di-label">Escalation Point</div>
        <div class="di-value">${escapeHtml(r.escalationPoint)}</div>
      </div>
      <div class="detail-item">
        <div class="di-label">Escalation Point Email</div>
        <div class="di-value mono">${escapeHtml(r.escalationPointEmail)}</div>
      </div>
      <div class="detail-item">
        <div class="di-label">ASM</div>
        <div class="di-value">${escapeHtml(r.asmName)}</div>
      </div>
      <div class="detail-item">
        <div class="di-label">ASM Email</div>
        <div class="di-value mono">${escapeHtml(r.asmEmail)}</div>
      </div>
    </div>
  `;

  const modal = new bootstrap.Modal(document.getElementById("viewAppModal"));
  modal.show();
}

/* ==========================================================================
   DELETE APPLICATION
   ========================================================================== */
function appOpenDeleteConfirm(id) {
  const r = appAllRecords.find(x => x.id === id);
  if (!r) return;
  appPendingDeleteId = id;
  document.getElementById("deleteAppName").textContent = r.application;
  const modal = new bootstrap.Modal(document.getElementById("deleteAppModal"));
  modal.show();
}

function appConfirmDelete() {
  if (!appPendingDeleteId) return;
  appAllRecords = appAllRecords.filter(r => r.id !== appPendingDeleteId);
  appPendingDeleteId = null;

  appRefreshFilterOptions();
  appRenderSummary();
  appCurrentPage = 1;
  appApplyFilters();

  const modalEl = document.getElementById("deleteAppModal");
  bootstrap.Modal.getInstance(modalEl)?.hide();
}

/* ==========================================================================
   IMPORT (bulk-load applications from an Excel/CSV file)
   ========================================================================== */
function appImportRecordsFromRows(rows) {
  const headerToKey = {};
  APP_EXPORT_COLUMNS.forEach(col => { headerToKey[col.header] = col.key; });

  let importedCount = 0;
  rows.forEach(row => {
    const rec = {};
    Object.keys(row).forEach(header => {
      const key = headerToKey[header];
      if (!key) return;
      let val = row[header];
      if (val === "\u2014" || val === undefined || val === null) val = "";
      rec[key] = String(val).trim();
    });
    if (!rec.application) return; // skip rows without at least an Application value

    const parts = parseApplicationParts(rec.application);
    if (!rec.gearId) rec.gearId = parts.gearId;
    if (!rec.country) rec.country = parts.country;
    rec.appName = parts.name;
    rec.id = `app-import-${appNextSeq++}`;

    appAllRecords.unshift(rec);
    importedCount++;
  });
  return importedCount;
}

function appHandleImportFile(e) {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (evt) => {
    try {
      const data = new Uint8Array(evt.target.result);
      const workbook = XLSX.read(data, { type: "array" });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(sheet, { defval: "" });
      const count = appImportRecordsFromRows(rows);

      appRefreshFilterOptions();
      appRenderSummary();
      appCurrentPage = 1;
      appApplyFilters();

      if (count > 0) {
        showToast(`${count} application${count === 1 ? "" : "s"} imported successfully.`);
      } else {
        showToast("No matching rows found in that file. Expected an \u2018Application\u2019 column at minimum.", "error");
      }
      // NOTE: once this page is connected to the SharePoint Application
      // Inventory list, each imported row above should also be written to
      // that list here (e.g. via a Power Automate HTTP flow or the
      // SharePoint REST/Graph API) so the list stays in sync with what's
      // shown in the browser.
    } catch (err) {
      console.error(err);
      showToast("Could not read that file. Please upload a valid Excel or CSV export.", "error");
    }
  };
  reader.readAsArrayBuffer(file);
  e.target.value = ""; // allow re-selecting the same file later
}

/* ==========================================================================
   EXPORT (exports all currently filtered applications to an Excel file)
   ========================================================================== */
const APP_EXPORT_COLUMNS = [
  { header: "Application", key: "application" },
  { header: "Gear ID", key: "gearId" },
  { header: "Country", key: "country" },
  { header: "ADM / Non-ADM", key: "admStatus" },
  { header: "Decom Path", key: "decomPath" },
  { header: "App Owner", key: "appOwner" },
  { header: "App Owner Email", key: "appOwnerEmail" },
  { header: "Escalation Point", key: "escalationPoint" },
  { header: "Escalation Point Email", key: "escalationPointEmail" },
  { header: "ASM Name", key: "asmName" },
  { header: "ASM Email", key: "asmEmail" }
];

function appDownloadAllRecords() {
  if (!appFilteredRecords.length) return;

  const rows = appFilteredRecords.map(r => {
    const row = {};
    APP_EXPORT_COLUMNS.forEach(col => {
      const raw = r[col.key];
      row[col.header] = (raw === undefined || raw === null || raw === "") ? "\u2014" : raw;
    });
    return row;
  });

  const worksheet = XLSX.utils.json_to_sheet(rows, { header: APP_EXPORT_COLUMNS.map(c => c.header) });
  worksheet["!cols"] = APP_EXPORT_COLUMNS.map(c => ({ wch: Math.max(12, Math.min(42, c.header.length + 6)) }));

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Application Inventory");

  const dateStamp = new Date().toISOString().slice(0, 10);
  XLSX.writeFile(workbook, `application_inventory_export_${appFilteredRecords.length}records_${dateStamp}.xlsx`);
}

/* ==========================================================================
   EVENTS
   ========================================================================== */
function appWireEvents() {
  const searchInput = document.getElementById("appSearchInput");
  const searchClear = document.getElementById("appSearchClear");

  searchInput.addEventListener("input", () => {
    searchClear.classList.toggle("d-none", searchInput.value.length === 0);
    appCurrentPage = 1;
    appApplyFilters();
  });
  searchClear.addEventListener("click", () => {
    searchInput.value = "";
    searchClear.classList.add("d-none");
    appCurrentPage = 1;
    appApplyFilters();
  });

  const APP_FILTER_IDS = [
    "appFilterCountry", "appFilterAdm", "appFilterDecom",
    "appFilterAsm", "appFilterOwner", "appFilterEscalation"
  ];
  APP_FILTER_IDS.forEach(id => {
    document.getElementById(id).addEventListener("change", () => {
      appCurrentPage = 1;
      appApplyFilters();
    });
  });

  const appResetFilters = () => {
    APP_FILTER_IDS.forEach(id => { document.getElementById(id).value = ""; });
    searchInput.value = "";
    searchClear.classList.add("d-none");
    appCurrentPage = 1;
    appApplyFilters();
  };
  document.getElementById("appResetFiltersBtn").addEventListener("click", appResetFilters);
  document.getElementById("appEmptyResetBtn").addEventListener("click", appResetFilters);

  document.querySelectorAll("#appRecordsTable thead th[data-sort]").forEach(th => {
    th.addEventListener("click", () => {
      const key = th.dataset.sort;
      if (appSortState.key === key) {
        appSortState.dir = appSortState.dir === "asc" ? "desc" : "asc";
      } else {
        appSortState = { key, dir: "asc" };
      }
      appSortRecords();
      appRenderTable();
    });
  });

  document.getElementById("appFirstPage").addEventListener("click", () => {
    if (appCurrentPage > 1) { appCurrentPage = 1; appRenderTable(); }
  });
  document.getElementById("appPrevPage").addEventListener("click", () => {
    if (appCurrentPage > 1) { appCurrentPage--; appRenderTable(); }
  });
  document.getElementById("appNextPage").addEventListener("click", () => {
    appCurrentPage++; appRenderTable();
  });
  document.getElementById("appLastPage").addEventListener("click", () => {
    const totalPages = Math.max(1, Math.ceil(appFilteredRecords.length / APP_PAGE_SIZE));
    if (appCurrentPage < totalPages) { appCurrentPage = totalPages; appRenderTable(); }
  });

  const pageJumpInput = document.getElementById("appPageJumpInput");
  const goToTypedPage = () => {
    const totalPages = Math.max(1, Math.ceil(appFilteredRecords.length / APP_PAGE_SIZE));
    let target = parseInt(pageJumpInput.value, 10);
    if (!Number.isFinite(target)) target = appCurrentPage;
    target = Math.min(Math.max(target, 1), totalPages);
    appCurrentPage = target;
    appRenderTable();
  };
  pageJumpInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      goToTypedPage();
      pageJumpInput.blur();
    }
  });
  pageJumpInput.addEventListener("blur", () => {
    pageJumpInput.value = String(appCurrentPage);
  });

  const pageSizeSelect = document.getElementById("appPageSizeSelect");
  pageSizeSelect.value = String(APP_PAGE_SIZE);
  pageSizeSelect.addEventListener("change", (e) => {
    APP_PAGE_SIZE = parseInt(e.target.value, 10);
    appCurrentPage = 1;
    appRenderTable();
  });

  document.getElementById("appExportBtn").addEventListener("click", () => {
    appDownloadAllRecords();
  });

  document.getElementById("topbarAddAppBtn").addEventListener("click", appOpenAddModal);
  document.getElementById("addAppForm").addEventListener("submit", appHandleAddSubmit);
  document.getElementById("confirmDeleteBtn").addEventListener("click", appConfirmDelete);

  document.getElementById("topbarImportAppBtn").addEventListener("click", () => {
    document.getElementById("appImportFileInput").click();
  });
  document.getElementById("appImportFileInput").addEventListener("change", appHandleImportFile);
}

/* ==========================================================================
   INIT
   ========================================================================== */
document.addEventListener("DOMContentLoaded", () => {
  loadAppInventory();
  appPopulateAddCountryOptions();
  appRefreshFilterOptions();
  appRenderSummary();
  appWireEvents();
  appApplyFilters();
});
