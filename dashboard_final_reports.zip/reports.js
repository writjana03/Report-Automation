/* ==========================================================================
   REPORTS / INSIGHTS
   Additive module: reads the same `allRecords` produced by loadRecords() in
   script.js and reuses its shared helpers/lookups (REGION_META,
   riskPriorityMeta, statusStyle, escapeHtml, formatDate, slaBadge, riskBadge,
   statusBadge, slaCountdownText, AGE_BUCKET_ORDER). Nothing in script.js is
   modified by this file — it only reads the globals it already exposes.
   Charts are built with Chart.js (loaded via CDN in index.html).
   ========================================================================== */

// Palette pulled from style.css design tokens so the charts match the rest
// of the app instead of using Chart.js defaults.
const REPORT_COLORS = {
  accent:  "#0E7C7B",
  accentSoft: "#CFE9E8",
  danger:  "#C6483B",
  dangerBg:"#FBEAE8",
  warning: "#B9791A",
  warningBg:"#FCF1DE",
  info:    "#4C5FD6",
  infoBg:  "#EBEDFC",
  success: "#2C8C55",
  successBg:"#E6F5EC",
  high:    "#D9822B",
  highBg:  "#FCE8D5",
  neutral: "#8A97A2",
  neutralBg:"#EDF1F4"
};

const RISK_COLORS   = { 1: REPORT_COLORS.danger, 2: REPORT_COLORS.high, 3: REPORT_COLORS.warning, 4: REPORT_COLORS.info, 5: REPORT_COLORS.neutral };
const SLA_COLORS     = { "Within SLA": REPORT_COLORS.success, "Potential Fail": REPORT_COLORS.high, "Outside SLA": REPORT_COLORS.danger };
const REGION_COLORS  = { APAC: REPORT_COLORS.accent, EMEA: REPORT_COLORS.info, AMER: REPORT_COLORS.high, Other: REPORT_COLORS.neutral };

function reportsAgeBucket(ageDays) {
  if (ageDays <= 30) return "0-30 days";
  if (ageDays <= 60) return "30-60 days";
  if (ageDays <= 90) return "60-90 days";
  if (ageDays <= 180) return "90-180 days";
  return "180+ days";
}

function reportsTopEntries(countsObj, limit) {
  return Object.entries(countsObj)
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit);
}

/* --------------------------------------------------------------------------
   KPI CARDS
   -------------------------------------------------------------------------- */
function renderReportsKpis(openRecords, closedRecords) {
  const total = openRecords.length;
  const critical = openRecords.filter(r => r.riskPriority <= 2).length;
  const outsideSla = openRecords.filter(r => r.sla === "Outside SLA").length;
  const potentialFail = openRecords.filter(r => r.sla === "Potential Fail").length;
  const avgAge = total ? Math.round(openRecords.reduce((sum, r) => sum + (r.age || 0), 0) / total) : 0;
  const closedCount = closedRecords.length;

 const cards = [
  {
    key: "total",
    icon: "bi-collection-fill",
    cls: "sc-total",
    value: total,
    label: "Total Open Records"
  },
  {
    key: "critical",
    icon: "bi-exclamation-octagon-fill",
    cls: "sc-expiring",
    value: critical,
    label: "Critical (P1/P2) Open"
  },
  {
    key: "outside",
    icon: "bi-hourglass-split",
    cls: "sc-pending",
    value: outsideSla,
    label: "SLA Breached"
  },
  {
    key: "potential",
    icon: "bi-alarm-fill",
    cls: "sc-feedback",
    value: potentialFail,
    label: "Potential Fail (≤ 15 days)"
  },

  {
    key: "closed",
    icon: "bi-check-circle-fill",
    cls: "sc-resolved",
    value: closedCount,
    label: "Closed Records"
  }
];

  const grid = document.getElementById("reportsKpiGrid");
  if (!grid) return;
  grid.innerHTML = cards.map(c => `
    <div class="summary-card ${c.cls}" data-key="${c.key}">
      <div class="sc-top">
        <span class="sc-icon"><i class="bi ${c.icon}"></i></span>
      </div>
      <div class="sc-value">${c.value}</div>
      <div class="sc-label">${c.label}</div>
    </div>
  `).join("");
  grid
 .querySelectorAll(
   ".summary-card"
 )
 .forEach(card => {

   card.style.cursor =
     "pointer";

   card.onclick = () => {

     const key =
       card.dataset.key;

     let rows = [];
     let title = "";

     if(key === "total"){

       rows = openRecords;
       title =
         "Total Open Records";

     }

     if(key === "critical"){

       rows =
         openRecords.filter(
           r =>
             r.riskPriority <= 2
         );

       title =
         "Critical (P1/P2) Open";

     }

     if(key === "outside"){

       rows =
         openRecords.filter(
           r =>
             r.sla ===
             "Outside SLA"
         );

       title =
         "SLA Breached";

     }

     if(key === "potential"){

       rows =
         openRecords.filter(
           r =>
             r.sla ===
             "Potential Fail"
         );

       title =
         "Potential Fail";

     }



     if(key === "closed"){

       rows = closedRecords;

       title =
         "Closed Records";

     }

     openReportDrilldownModal(
       title,
       rows
     );

   };

 });

  return { total, critical, outsideSla, potentialFail, avgAge, closedCount };
}

/* --------------------------------------------------------------------------
   AUTO-GENERATED INSIGHTS
   -------------------------------------------------------------------------- */
function renderReportsInsights(openRecords, kpis) {
  const list = document.getElementById("insightsList");
  if (!list) return;

  const insights = [];

  // Region concentration
  const byRegion = {};
  openRecords.forEach(r => { byRegion[r.region] = (byRegion[r.region] || 0) + 1; });
  const [topRegionName, topRegionCount] = reportsTopEntries(byRegion, 1)[0] || [null, 0];
  if (topRegionName && kpis.total) {
    const pct = Math.round((topRegionCount / kpis.total) * 100);
    insights.push({
      tone: pct >= 50 ? "warning" : "neutral",
      icon: "bi-globe-asia-australia",
      html: `<strong>${escapeHtml(topRegionName)}</strong> carries the largest share of open records &mdash; ${topRegionCount} of ${kpis.total} (${pct}%).`
    });
  }

  // SLA breach severity
  if (kpis.outsideSla > 0) {
    const critBreached = openRecords.filter(r => r.sla === "Outside SLA" && r.riskPriority <= 2).length;
    insights.push({
      tone: "danger",
      icon: "bi-exclamation-triangle-fill",
      html: `<strong>${kpis.outsideSla}</strong> record${kpis.outsideSla === 1 ? "" : "s"} ${kpis.outsideSla === 1 ? "is" : "are"} currently outside SLA${critBreached ? `, including <strong>${critBreached}</strong> at Critical/High priority` : ""}.`
    });
  } else {
    insights.push({ tone: "success", icon: "bi-check-circle-fill", html: `No open records are currently outside SLA.` });
  }

  if (kpis.potentialFail > 0) {
    insights.push({
      tone: "warning",
      icon: "bi-alarm-fill",
      html: `<strong>${kpis.potentialFail}</strong> record${kpis.potentialFail === 1 ? "" : "s"} will breach SLA within 15 days if not remediated soon.`
    });
  }

  // Oldest record
  const oldest = [...openRecords].sort((a, b) => (b.age || 0) - (a.age || 0))[0];
  if (oldest) {
    insights.push({
      tone: "neutral",
      icon: "bi-clock-history",
      html: `The oldest open record is <strong>${escapeHtml(oldest.vulnerabilityName)}</strong> on ${escapeHtml(oldest.application)}, open for <strong>${oldest.age} days</strong>.`
    });
  }

  // Assignment group concentration
  const byGroup = {};
  openRecords.forEach(r => { byGroup[r.assignmentGroup] = (byGroup[r.assignmentGroup] || 0) + 1; });
  const [topGroupName, topGroupCount] = reportsTopEntries(byGroup, 1)[0] || [null, 0];
  if (topGroupName) {
    insights.push({
      tone: "neutral",
      icon: "bi-people-fill",
      html: `<strong>${escapeHtml(topGroupName)}</strong> is carrying the most open work of any assignment group (${topGroupCount} record${topGroupCount === 1 ? "" : "s"}).`
    });
  }

  // Status category bottleneck
  const byStatusCat = {};
  openRecords.forEach(r => { byStatusCat[r.statusCategory] = (byStatusCat[r.statusCategory] || 0) + 1; });
  const [topStatusCat, topStatusCatCount] = reportsTopEntries(byStatusCat, 1)[0] || [null, 0];
  if (topStatusCat) {
    insights.push({
      tone: "neutral",
      icon: "bi-clipboard-data-fill",
      html: `<strong>${escapeHtml(topStatusCat)}</strong> is the most common status category, holding <strong>${topStatusCatCount}</strong> open record${topStatusCatCount === 1 ? "" : "s"}.`
    });
  }

  list.innerHTML = insights.map(i => `
    <li class="insight-${i.tone}">
      <i class="bi ${i.icon}"></i>
      <span>${i.html}</span>
    </li>
  `).join("") || `<li><i class="bi bi-info-circle"></i><span>No open records to summarize right now.</span></li>`;
}

/* --------------------------------------------------------------------------
   CHARTS — pure CSS/HTML, no external charting library.
   Doughnuts use a CSS conic-gradient with a masked-out center; every other
   chart is a simple flex-based (stacked) bar. This has zero network
   dependency, unlike a CDN-hosted chart library, so it always renders.
   -------------------------------------------------------------------------- */
function reportsRenderDoughnut(containerId, entries, colorMap, totalLabel) {
  const el = document.getElementById(containerId);
  if (!el) return;
  const total = entries.reduce((sum, e) => sum + e[1], 0);
  if (!total) { el.innerHTML = `<p class="chart-empty-note">No data to show.</p>`; return; }

  let cursor = 0;
  const stops = entries.map(([label, value]) => {
    const color = colorMap[label] || REPORT_COLORS.neutral;
    const start = (cursor / total) * 100;
    cursor += value;
    const end = (cursor / total) * 100;
    return `${color} ${start}% ${end}%`;
  }).join(", ");

  const legend = entries.map(([label, value]) => {
    const color = colorMap[label] || REPORT_COLORS.neutral;
    const pct = total ? Math.round((value / total) * 100) : 0;
    return `
      <div class="donut-legend-row report-clickable" data-label="${label}">
        <span class="donut-legend-dot" style="background:${color}"></span>
        <span class="donut-legend-label">${escapeHtml(label)}</span>
        <span class="donut-legend-value">${value} <span class="donut-legend-pct">(${pct}%)</span></span>
      </div>`;
  }).join("");

  el.innerHTML = `
    <div class="donut-layout">
      <div class="donut-ring" style="background: conic-gradient(${stops});">
        <div class="donut-ring-hole">
          <div class="donut-ring-total">${total}</div>
          <div class="donut-ring-total-label">${escapeHtml(totalLabel)}</div>
        </div>
      </div>
      <div class="donut-legend">${legend}</div>
    </div>`;
}

function reportsRenderBarList(containerId, entries, colorFor, options) {
  const opts = options || {};
  const el = document.getElementById(containerId);
  if (!el) return;
  if (!entries.length) { el.innerHTML = `<p class="chart-empty-note">No data to show.</p>`; return; }
  const max = Math.max(...entries.map(e => e[1]), 1);

  el.innerHTML = `
    <div class="bar-list country-chart-list">
      ${entries.map(([label, value]) => {
        const pct = Math.max((value / max) * 100, value > 0 ? 3 : 0);
        const color = typeof colorFor === "function" ? colorFor(label) : colorFor;
        return `
          <div class="bar-row">
            <span class="bar-row-label" title="${escapeHtml(label)}">${escapeHtml(opts.truncateLabels ? reportsTruncate(label, 26) : label)}</span>
            <span class="bar-row-track">
              <span class="bar-row-fill" style="width:${pct}%; background:${color};"></span>
            </span>
            <span class="bar-row-value">${value}</span>
          </div>`;
      }).join("")}
    </div>`;
}

function reportsRenderStackedBarList(containerId, groupLabels, seriesDefs) {
  const el = document.getElementById(containerId);
  if (!el) return;
  if (!groupLabels.length) { el.innerHTML = `<p class="chart-empty-note">No data to show.</p>`; return; }

  const totals = groupLabels.map((_, i) => seriesDefs.reduce((sum, s) => sum + s.values[i], 0));
  const max = Math.max(...totals, 1);

  const legend = seriesDefs.map(s => `
    <div class="donut-legend-row stacked-legend-row">
      <span class="donut-legend-dot" style="background:${s.color}"></span>
      <span class="donut-legend-label">${escapeHtml(s.label)}</span>
    </div>`).join("");

  const rows = groupLabels.map((label, i) => {
    const total = totals[i];
    const segments = seriesDefs.map(s => {
      const value = s.values[i];
      if (!value) return "";
      const pct = (value / max) * 100;
      return `<span class="bar-row-fill stacked-segment" style="width:${pct}%; background:${s.color};" title="${escapeHtml(s.label)}: ${value}"></span>`;
    }).join("");
    return `
      <div class="bar-row">
        <span class="bar-row-label">${escapeHtml(label)}</span>
        <span class="bar-row-track stacked-track">${segments}</span>
        <span class="bar-row-value">${total}</span>
      </div>`;
  }).join("");

  el.innerHTML = `<div class="stacked-chart-wrap"><div class="bar-list">${rows}</div><div class="stacked-legend">${legend}</div></div>`;
}

function reportsTruncate(str, max) {
  const s = String(str);
  return s.length > max ? s.slice(0, max - 1) + "\u2026" : s;
}

function renderReportsCharts(openRecords) {
  // 1) Risk priority breakdown (doughnut)
  const riskCounts = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
  openRecords.forEach(r => { riskCounts[r.riskPriority] = (riskCounts[r.riskPriority] || 0) + 1; });
  const riskEntries = Object.keys(riskCounts)
    .filter(k => riskCounts[k] > 0)
    .map(k => [(riskPriorityMeta[k] || {}).label || `Risk ${k}`, riskCounts[k], k]);
  const riskColorMap = {};
  riskEntries.forEach(([label, , k]) => { riskColorMap[label] = RISK_COLORS[k] || REPORT_COLORS.neutral; });
  reportsRenderDoughnut("chartRiskPriority", riskEntries.map(([l, v]) => [l, v]), riskColorMap, "Open");
  document
  .querySelectorAll(
    "#chartRiskPriority .report-clickable"
  )
  .forEach(item => {

    item.onclick = () => {

      const label =
        item.dataset.label;

      const rows =
        reportsOpenRecordsCache.filter(
          r =>
            (riskPriorityMeta[
              r.riskPriority
            ] || {}).label === label
        );

      openReportDrilldownModal(
        label,
        rows
      );

    };

  });
  // 2) SLA compliance (doughnut)
  const slaOrder = ["Within SLA", "Potential Fail", "Outside SLA"];
  const slaCounts = { "Within SLA": 0, "Potential Fail": 0, "Outside SLA": 0 };
  openRecords.forEach(r => { slaCounts[r.sla] = (slaCounts[r.sla] || 0) + 1; });
  reportsRenderDoughnut("chartSlaCompliance", slaOrder.map(k => [k, slaCounts[k]]), SLA_COLORS, "Open");
document
  .querySelectorAll(
    "#chartSlaCompliance .report-clickable"
  )
  .forEach(item => {

    item.addEventListener(
      "click",
      () => {

        const label =
          item.dataset.label;

        const rows =
          reportsOpenRecordsCache.filter(
            r => r.sla === label
          );

        openReportDrilldownModal(
          label,
          rows
        );

      }
    );

  });
 // 3) Open Vulnerabilities by Country

const byCountry = {};

openRecords.forEach(r => {

  byCountry[r.country] =
    (byCountry[r.country] || 0) + 1;

});

const countryEntries =
  reportsTopEntries(
    byCountry,
    15
  );

reportsRenderBarList(
  "chartByRegion",
  countryEntries,
  REPORT_COLORS.accent,
  {
    truncateLabels: true
  }
);
const countryRows =
  document.querySelectorAll(
    "#chartByRegion .bar-row"
  );

countryRows.forEach((row, index) => {

  row.style.cursor = "pointer";

  row.onclick = () => {

    const country =
      countryEntries[index][0];

    const rows =
      reportsOpenRecordsCache.filter(
        r => r.country === country
      );

    openReportDrilldownModal(
      country,
      rows
    );

  };

});
  // 4) Age distribution
  const ageBuckets = AGE_BUCKET_ORDER;
  const ageCounts = {};
  ageBuckets.forEach(b => ageCounts[b] = 0);
  openRecords.forEach(r => { const b = reportsAgeBucket(r.age || 0); ageCounts[b] = (ageCounts[b] || 0) + 1; });
  const ageEntries = ageBuckets.map( b => [b, ageCounts[b]]);

  reportsRenderBarList( "chartAgeBuckets", ageEntries, REPORT_COLORS.accent);
  const ageRows =
  document.querySelectorAll(
    "#chartAgeBuckets .bar-row"
  );

ageRows.forEach((row, index) => {

  row.style.cursor = "pointer";

  row.onclick = () => {

    const bucket =
      ageEntries[index][0];

    const rows =
      reportsOpenRecordsCache.filter(
        r => r.ageRolling === bucket
      );

    openReportDrilldownModal(
      bucket,
      rows
    );

  };

});
  // 5) Status category (top 10)

const byStatusCat = {};

openRecords.forEach(r => {
  byStatusCat[r.statusCategory] =
    (byStatusCat[r.statusCategory] || 0) + 1;
});

const statusEntries =
  reportsTopEntries(
    byStatusCat,
    10
  );

reportsRenderBarList(
  "chartStatusCategory",
  statusEntries,
  REPORT_COLORS.info,
  { truncateLabels: true }
);

const statusRows =
  document.querySelectorAll(
    "#chartStatusCategory .bar-row"
  );

statusRows.forEach((row, index) => {

  row.style.cursor = "pointer";

  row.onclick = () => {

    const category =
      statusEntries[index][0];

    const rows =
      reportsOpenRecordsCache.filter(
        r =>
          r.statusCategory === category
      );

    openReportDrilldownModal(
      category,
      rows
    );

  };

});

  // 6) Top assignment groups (top 8)

const byGroup = {};

openRecords.forEach(r => {
  byGroup[r.assignmentGroup] =
    (byGroup[r.assignmentGroup] || 0) + 1;
});

const groupEntries =
  reportsTopEntries(
    byGroup,
    8
  );

reportsRenderBarList(
  "chartTopAssignmentGroups",
  groupEntries,
  REPORT_COLORS.high,
  { truncateLabels: true }
);

const groupRows =
  document.querySelectorAll(
    "#chartTopAssignmentGroups .bar-row"
  );

groupRows.forEach((row, index) => {

  row.style.cursor = "pointer";

  row.onclick = () => {

    const group =
      groupEntries[index][0];

    const rows =
      reportsOpenRecordsCache.filter(
        r =>
          r.assignmentGroup === group
      );

    openReportDrilldownModal(
      group,
      rows
    );

  };

});
  // 7) SLA status by country (filterable — Within SLA / Potential Fail / Outside SLA)
  reportsOpenRecordsCache = openRecords;
  const slaFilterSel = document.getElementById("countrySlaFilter");
  renderCountrySlaChart(openRecords, slaFilterSel ? slaFilterSel.value : "Potential Fail");
}

/* --------------------------------------------------------------------------
   SLA STATUS BY COUNTRY (filterable)
   -------------------------------------------------------------------------- */
let reportsOpenRecordsCache = [];
function openReportDrilldownModal(title, rows){

  const html = `
    <html>
    <head>
      <title>${title}</title>

      <style>

        body{
          font-family:Arial,sans-serif;
          padding:20px;
        }

        table{
          width:100%;
          border-collapse:collapse;
        }

        th,
        td{
          border:1px solid #ddd;
          padding:8px;
          text-align:left;
        }

        th{
          background:#2E5AAC;
          color:white;
        }

      </style>

    </head>

    <body>

      <h2>${title}</h2>

      <table>

        <tr>
          <th>Application</th>
          <th>Vulnerability</th>
          <th>QID</th>
          <th>Risk</th>
          <th>Status</th>
          <th>SLA</th>
          <th>Assignment Group</th>
        </tr>

        ${rows.map(r => `
          <tr>
            <td>${escapeHtml(r.application)}</td>
            <td>${escapeHtml(r.vulnerabilityName)}</td>
            <td>${escapeHtml(r.qid)}</td>
            <td>${escapeHtml(r.riskPriority)}</td>
            <td>${escapeHtml(r.currentStatus)}</td>
            <td>${escapeHtml(r.sla)}</td>
            <td>${escapeHtml(r.assignmentGroup)}</td>
          </tr>
        `).join("")}

      </table>

    </body>
    </html>
  `;

  const w = window.open(
    "",
    "_blank",
    "width=1200,height=700"
  );

  w.document.write(html);
  w.document.close();
}
function renderCountrySlaChart(openRecords, status) {

  const byCountry = {};

  openRecords
    .filter(r => r.sla === status)
    .forEach(r => {

      byCountry[r.country] =
        (byCountry[r.country] || 0) + 1;

    });

  const entries =
    reportsTopEntries(
      byCountry,
      12
    );

  const color =
    SLA_COLORS[status] ||
    REPORT_COLORS.neutral;

  reportsRenderBarList(
    "chartCountrySla",
    entries,
    color,
    { truncateLabels: true }
  );

  const countryRows =
    document.querySelectorAll(
      "#chartCountrySla .bar-row"
    );

  countryRows.forEach((row, index) => {

    row.style.cursor = "pointer";

    row.onclick = () => {

      const country =
        entries[index][0];

      const rows =
        reportsOpenRecordsCache.filter(
          r =>
            r.country === country &&
            r.sla === status
        );

      openReportDrilldownModal(
        `${country} - ${status}`,
        rows
      );

    };

  });

}

/* --------------------------------------------------------------------------
   SLA WATCHLIST TABLE
   -------------------------------------------------------------------------- */
function renderReportsWatchlist(openRecords) {
  const body = document.getElementById("reportsWatchlistBody");
  if (!body) return;

  const top10 = [...openRecords]
    .sort((a, b) => {
      if (a.riskPriority !== b.riskPriority) return a.riskPriority - b.riskPriority;
      return a.slaDaysRemaining - b.slaDaysRemaining;
    })
    .slice(0, 10);

  body.innerHTML = top10.map(r => `
    <tr>
      <td>${escapeHtml(r.application)}</td>
      <td>${escapeHtml(r.vulnerabilityName)}</td>
      <td>${riskBadge(r.riskPriority)}</td>
      <td>${escapeHtml(r.region)}</td>
      <td>${escapeHtml(r.statusCategory)}</td>
      <td>${escapeHtml(r.assignmentGroup)}</td>
      <td>${slaBadge(r.sla)}<br>${slaCountdownText(r)}</td>
    </tr>
  `).join("") || `<tr><td colspan="7" class="text-muted">No open records available.</td></tr>`;
}

/* --------------------------------------------------------------------------
   WEEKLY STATUS REPORT (Excel — 2 tabs: Outside SLA / Potential Fail)
   Respects whatever filters are currently applied elsewhere in the app
   (region/country/sla/search etc. via the shared `filteredRecords` global
   from script.js), falling back to the full dataset if nothing is filtered.
   -------------------------------------------------------------------------- */
const WEEKLY_STATUS_REPORT_COLUMNS = [
  { header: "Title", key: "vulnerabilityName" },
  { header: "Application", key: "application" },
  { header: "Remediation Plan", key: "remediationPlan" },
  { header: "Remediation Owner", key: "remediationOwner" },
  { header: "Target ETA", key: "targetETA" },
  { header: "Title Owner", key: "assignee" }
];

// Groups records by Application so an application with several vulnerability
// Titles appears as ONE row, with each field's values stacked line-by-line
// (same order as the titles) inside their respective cells. If the same
// Title text repeats within an application, the 2nd+ occurrence is suffixed
// "- 2", "- 3", etc. so it's still distinguishable on its own line.
function weeklyStatusReportRows(records) {
  const groups = new Map(); // application -> ordered array of records
  records.forEach(r => {
    const app = (r.application === undefined || r.application === null || r.application === "") ? "\u2014" : r.application;
    if (!groups.has(app)) groups.set(app, []);
    groups.get(app).push(r);
  });

  const rows = [];
  groups.forEach((groupRecords, app) => {
    const titleCounts = {};
    const titleLines = groupRecords.map(r => {
      const rawTitle = (r.vulnerabilityName === undefined || r.vulnerabilityName === null || r.vulnerabilityName === "") ? "\u2014" : r.vulnerabilityName;
      titleCounts[rawTitle] = (titleCounts[rawTitle] || 0) + 1;
      const occurrence = titleCounts[rawTitle];
      return occurrence > 1 ? `${rawTitle} - ${occurrence}` : rawTitle;
    });

    rows.push(WEEKLY_STATUS_REPORT_COLUMNS.map(col => {
      if (col.key === "application") return app;
      if (col.key === "vulnerabilityName") return titleLines.join("\n");
      return groupRecords.map(r => {
        const raw = r[col.key];
        return (raw === undefined || raw === null || raw === "") ? "\u2014" : raw;
      }).join("\n");
    }));
  });
  return rows;
}

/* --------------------------------------------------------------------------
   OVERALL STATUS TAB (Master Vulnerability Report grid)
   Column A = parent/child Status + Status Category taxonomy.
   Column B ("Qualys (BU Managed)") = live counts from allRecords, matched
   by normalized Status Category text. Columns C-O are placeholders for
   other tools (CSPM, Taas, Imperva, etc.) not yet wired to live data.
   -------------------------------------------------------------------------- */
const OVERALL_STATUS_COLORS = {
  grey: "A6A6A6",
  lightGrey: "D9D9D9",
  yellow: "FFFF00",
  lightPurple: "D9D2E9",
  orange: "FFC000",
  darkPurple: "7030A0"
};

// Ordered taxonomy: each parent (purple) row followed by its child rows.
// `match` is the raw Status Category text (from real data) this child maps
// to, normalized (case/punctuation-insensitive) at count time. `match: null`
// means "no equivalent category exists in the current dataset yet" (counts
// as 0 until that category starts appearing in real data).
const OVERALL_STATUS_TAXONOMY = [
  { label: "Inprogress", parent: true, children: [
    { label: "Request/ CHG Path", match: null }, // dataset uses "ODR/CHG Path" — different wording, not auto-mapped; confirm if these should be treated as the same category
    { label: "BAU - EPM Patching", match: "BAU EPM Patching" },
    { label: "BAU - EPM Patching - ADHOC", match: null },
    { label: "BAU Investigation", match: "BAU Investigation" },
    { label: "BAU Others", match: "BAU Others" },
    { label: "For Rescan", match: "For Rescan" }
  ]},
  { label: "Pending", parent: true, children: [
    { label: "Onhold", match: null },
    { label: "Feedback Required", match: "Feedback Required" },
    { label: "To be Actioned", match: null },
    { label: "Ongoing Investigation", match: null }
  ]},
  { label: "Out of Scope", parent: true, children: [
    { label: "OOS - DBA Owned", match: null },
    { label: "OOS - Scope", match: "OOS Scope" },
    { label: "OOS - Citrix", match: null }
  ]},
  { label: "Closed", parent: true, children: [
    { label: "Closed as per Rescan", match: "Closed as per rescan" }
  ]},
  { label: "Not Applicable", parent: true, children: [
    { label: "Marked as Success", match: null }
  ]},
  { label: "RA", parent: true, children: [
    { label: "LTR", match: "LTR" },
    { label: "RA- For Submission", match: null },
    { label: "RA - Pending Approval", match: null }
  ]},
  { label: "Decom Path", parent: true, children: [
    { label: "Decom App", match: null },
    { label: "Decom Server", match: "Decom (Server)" }
  ]},
  { label: "Others", parent: true, children: [
    { label: "Others", match: "Others" }
  ]}
];

function normalizeStatusText(s) {
  return String(s == null ? "" : s).toLowerCase().replace(/[^a-z0-9]+/g, " ").trim().replace(/\s+/g, " ");
}

function buildOverallStatusSheet(records) {
  const counts = {}; // normalized statusCategory -> count
  records.forEach(r => {
    const key = normalizeStatusText(r.statusCategory);
    counts[key] = (counts[key] || 0) + 1;
  });
  const countFor = (matchText) => matchText ? (counts[normalizeStatusText(matchText)] || 0) : 0;

  const C = OVERALL_STATUS_COLORS;
  const cells = [];
  const merges = [];

  function mergedBlock(ref, value, style) {
    const m = /^([A-Z]+)(\d+):([A-Z]+)(\d+)$/.exec(ref);
    const colLetterToIdx = (s) => { let n = 0; for (let i = 0; i < s.length; i++) n = n * 26 + (s.charCodeAt(i) - 64); return n - 1; };
    const c1 = colLetterToIdx(m[1]), r1 = parseInt(m[2], 10), c2 = colLetterToIdx(m[3]), r2 = parseInt(m[4], 10);
    merges.push(ref);
    for (let r = r1; r <= r2; r++) {
      for (let c = c1; c <= c2; c++) {
        const ref2 = String.fromCharCode(65 + c) + r; // works for single-letter cols (A-Z), sufficient here
        cells.push({ ref: ref2, value: (r === r1 && c === c1) ? value : "", style });
      }
    }
  }

  // Row 1: top-level group headers
  mergedBlock("A1:A3", "Master Vulnerability Report", { fill: C.grey, bold: true, align: "center", valign: "center" });
  mergedBlock("B1:G1", "Infra Security", { fill: C.yellow, bold: true, align: "center", valign: "center" });
  mergedBlock("H1:J1", "IAM", { fill: C.lightPurple, bold: true, align: "center", valign: "center" });
  mergedBlock("K1:M1", "Monitoring and Response", { fill: C.orange, bold: true, align: "center", valign: "center" });
  mergedBlock("N1:O1", "infra security", { fill: C.yellow, bold: true, align: "center", valign: "center" });

  // Row 2: tool/source names (light grey)
  const row2Labels = ["Qualys (BU Managed)", "Qualys (BAU Managed)", "CSPM", "Taas (Tanium)", "Imperva (Prod Db)", "CMDB Health",
    "IAM Terms", "MFA", "SSL Cert", "Security Stack", "WAF", "API Security", "NPT", "EOL"];
  row2Labels.forEach((label, i) => {
    const col = String.fromCharCode(66 + i); // B..O
    cells.push({ ref: col + "2", value: label, style: { fill: C.lightGrey, bold: true, align: "center", valign: "center" } });
  });

  // Row 3: owners (yellow)
  const row3Labels = ["All", "P: Sasirekha\nS: Anusha", "P: Sasirekha\nS: Anusha", "P: Sasirekha\nS: Anusha", "P: Sasirekha\nS: Anusha", "P: Sasirekha\nS: Anusha",
    "P: Dinesh\nS: Anusha", "P: Sasirekha\nS: Dinesh", "P: Anusha\nS: Dinesh", "P: Sasirekha\nS: Dinesh", "P: Sasirekha\nS: Dinesh", "P: Sasirekha\nS: Dinesh",
    "P: Sasirekha\nS: Dinesh", "P: Sasirekha\nS: Dinesh"];
  row3Labels.forEach((label, i) => {
    const col = String.fromCharCode(66 + i);
    cells.push({ ref: col + "3", value: label, style: { fill: C.yellow, align: "center", valign: "center" } });
  });

  // Row 4: "All" — total record count feeding the Qualys (BU Managed) column
  cells.push({ ref: "A4", value: "All", style: { bold: true } });
  cells.push({ ref: "B4", value: records.length, style: { bold: true, align: "center" } });

  // Rows 5+: status taxonomy in column A, counts in column B
  let rowNum = 5;
  let grandTotal = 0;
  OVERALL_STATUS_TAXONOMY.forEach(group => {
    const parentRow = rowNum;
    let parentTotal = 0;
    rowNum++; // reserve the parent row, fill children first so we know the sum
    const childRows = [];
    group.children.forEach(child => {
      const count = countFor(child.match);
      parentTotal += count;
      childRows.push({ row: rowNum, label: child.label, count });
      rowNum++;
    });

    cells.push({ ref: "A" + parentRow, value: group.label, style: { fill: C.darkPurple, bold: true, fontColor: "FFFFFF" } });
    cells.push({ ref: "B" + parentRow, value: parentTotal, style: { fill: C.darkPurple, bold: true, fontColor: "FFFFFF", align: "center" } });
    childRows.forEach(cr => {
      cells.push({ ref: "A" + cr.row, value: cr.label });
      cells.push({ ref: "B" + cr.row, value: cr.count, style: { align: "center" } });
    });
    grandTotal += parentTotal;
  });

  cells.push({ ref: "A" + rowNum, value: "All Total Count", style: { fill: C.darkPurple, bold: true, fontColor: "FFFFFF" } });
  cells.push({ ref: "B" + rowNum, value: grandTotal, style: { fill: C.darkPurple, bold: true, fontColor: "FFFFFF", align: "center" } });

  return {
    name: "Overall Status",
    cells,
    merges,
    colWidths: [30, 20, 20, 14, 16, 16, 14, 14, 12, 12, 14, 12, 14, 10, 10]
  };
}


function downloadWeeklyStatusReport() {
  if (typeof XlsxLite === "undefined") {
    if (typeof showToast === "function") showToast("Report engine failed to load — try refreshing the page.", "error");
    return;
  }

  // Use whatever the rest of the app is currently filtered to (region/country/
  // sla/search from the main table view), falling back to all records.
  const source = (typeof filteredRecords !== "undefined" && filteredRecords.length)
    ? filteredRecords
    : (typeof allRecords !== "undefined" ? allRecords : []);

  const outsideSla = source.filter(r => r.sla === "Outside SLA");
  const potentialFail = source.filter(r => r.sla === "Potential Fail");
  const headers = WEEKLY_STATUS_REPORT_COLUMNS.map(c => c.header);
  const colWidths = WEEKLY_STATUS_REPORT_COLUMNS.map(c => Math.max(16, Math.min(42, c.header.length + 10)));

  const sheets = [
    buildOverallStatusSheet(source), // ALL records regardless of SLA status
    { name: "Outside SLA", headers, rows: weeklyStatusReportRows(outsideSla), colWidths },
    { name: "Potential Fail (15 days)", headers, rows: weeklyStatusReportRows(potentialFail), colWidths }
  ];

  const dateStamp = new Date().toISOString().slice(0, 10);
  XlsxLite.download(`weekly_status_report_${dateStamp}.xlsx`, sheets);

  if (typeof showToast === "function") {
    showToast(`Weekly Status Report downloaded (${outsideSla.length} Outside SLA, ${potentialFail.length} Potential Fail).`);
  }
}

/* --------------------------------------------------------------------------
   ENTRY POINT
   -------------------------------------------------------------------------- */
function renderReports() {
  if (!Array.isArray(allRecords) || !allRecords.length) return;

  const openRecords = allRecords.filter(r => r.currentStatus !== "Closed");
  const closedRecords = allRecords.filter(r => r.currentStatus === "Closed");

  const kpis = renderReportsKpis(openRecords, closedRecords);
  renderReportsInsights(openRecords, kpis);
  renderReportsCharts(openRecords);
  renderReportsWatchlist(openRecords);
}

document.addEventListener("DOMContentLoaded", () => {
  const refreshBtn = document.getElementById("reportsRefreshBtn");
  if (refreshBtn) {
    refreshBtn.addEventListener("click", (e) => {
      e.currentTarget.classList.add("spinning");
      setTimeout(() => e.currentTarget.classList.remove("spinning"), 500);
      renderReports();
    });
  }

  const countrySlaSel = document.getElementById("countrySlaFilter");
  if (countrySlaSel) {
    countrySlaSel.addEventListener("change", (e) => {
      renderCountrySlaChart(reportsOpenRecordsCache, e.target.value);
    });
  }

  // Self-contained dropdown toggle — deliberately does not depend on
  // Bootstrap's JS bundle, in case that CDN script is blocked on the
  // network. Only needs the browser's native click/keyboard events.
  const ddToggleBtn = document.getElementById("downloadReportBtn");
  const ddMenu = document.getElementById("downloadReportMenu");
  if (ddToggleBtn && ddMenu) {
    const closeMenu = () => {
      ddMenu.classList.remove("open");
      ddToggleBtn.setAttribute("aria-expanded", "false");
    };
    ddToggleBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      const isOpen = ddMenu.classList.toggle("open");
      ddToggleBtn.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });
    ddMenu.querySelectorAll("a").forEach(a => a.addEventListener("click", closeMenu));
    document.addEventListener("click", (e) => {
      if (!ddMenu.contains(e.target) && e.target !== ddToggleBtn) closeMenu();
    });
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeMenu(); });
  }

  const weeklyStatusBtn = document.getElementById("downloadWeeklyStatusReportBtn");
  if (weeklyStatusBtn) {
    weeklyStatusBtn.addEventListener("click", (e) => {
      e.preventDefault();
      downloadWeeklyStatusReport();
    });
  }

  const weeklyBtn = document.getElementById("downloadWeeklyReportBtn");
  if (weeklyBtn) {
    weeklyBtn.addEventListener("click", (e) => {
      e.preventDefault();
      if (typeof showToast === "function") showToast("Weekly Report (PPT) fields not defined yet — coming soon.", "error");
    });
  }

  const monthlyBtn = document.getElementById("downloadMonthlyReportBtn");
  if (monthlyBtn) {
    monthlyBtn.addEventListener("click", (e) => {
      e.preventDefault();
      downloadMonthlyReportPpt();
    });
  }
});
