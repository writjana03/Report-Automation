/* ==========================================================================
   RESOURCE INVENTORY PAGE
   Self-contained logic for the Resource Inventory tab (POC / escalation
   register). Reuses shared helpers already defined in script.js (escapeHtml,
   uniqueSorted) but keeps its own state so it never touches the
   Vulnerabilities or Application Inventory pages' behavior.
   Power Automate / API integration will later replace loadResourceInventory()
   and the add/delete handlers with live calls against a SharePoint list.
   ========================================================================== */

const RES_COUNTRY_LIST = ["AU", "SG", "MY", "TH", "TW", "CN", "ID", "PH", "HK", "VN", "NZ", "KR", "APAC"];
const RES_ENVIRONMENT_LIST = ["DEV", "SIT", "TEST", "UAT", "PROD"];
const RES_STATUS_LIST = ["Active", "Inactive", "Leave"];

/* ==========================================================================
   STATE
   ========================================================================== */
let resAllRecords = [];
let resFilteredRecords = [];
let resCurrentPage = 1;
let RES_PAGE_SIZE = 10;
let resSortState = { key: "application", dir: "asc" };
let resNextSeq = 1;
let resPendingDeleteId = null;
let resEditingId = null; // set while the Add/Update modal is editing an existing record

/* ==========================================================================
   DATA LOADING (swap this for a live Power Automate / API call later)
   ========================================================================== */
function parseResourceApplicationParts(applicationName) {
  const parts = String(applicationName).split(" - ");
  return {
    gearId: parts[0] ? parts[0].trim() : "",
    country: parts[1] ? parts[1].trim() : "Unknown",
    name: parts.slice(2).join(" - ").trim()
  };
}

function loadResourceInventory() {
  resAllRecords = RAW_RESOURCE_INVENTORY.map((r, i) => {
    const parts = parseResourceApplicationParts(r.application);
    return {
      id: `res-${i}`,
      country: parts.country,
      appName: parts.name,
      gearId: parts.gearId,
      ...r,
      pocs: resBuildPocsList(r)
    };
  });
  resNextSeq = resAllRecords.length + 1;
}

// Combines POC 1 / POC 2 (the source data's fixed two slots) into one list,
// so the table can show "all POCs for this app" without numbered columns.
function resBuildPocsList(r) {
  return [
    { name: r.poc1Name, email: r.poc1Email },
    { name: r.poc2Name, email: r.poc2Email }
  ].filter(p => p.name);
}

/* ==========================================================================
   BADGES
   ========================================================================== */
function resEnvBadge(environment) {
  const map = { PROD: "badge-danger", UAT: "badge-warning", SIT: "badge-info", TEST: "badge-orange", DEV: "badge-success" };
  const cls = map[environment] || "badge-neutral";
  return `<span class="badge-status ${cls}"><span class="dot"></span>${escapeHtml(environment)}</span>`;
}
function resStatusBadge(status) {
  const map = { Active: "badge-success", Inactive: "badge-neutral", Leave: "badge-warning" };
  const cls = map[status] || "badge-neutral";
  return `<span class="badge-status ${cls}"><span class="dot"></span>${escapeHtml(status)}</span>`;
}

/* ==========================================================================
   FILTER OPTIONS
   ========================================================================== */
function resRefreshFilterOptions() {
  const configs = [
    { id: "resFilterCountry", getter: r => r.country },
    { id: "resFilterEnvironment", getter: r => r.environment },
    { id: "resFilterStatus", getter: r => r.status },
    { id: "resFilterEscalation", getter: r => r.escalationLead },
    { id: "resFilterTeamDL", getter: r => r.teamDL }
  ];
  configs.forEach(cfg => {
    const sel = document.getElementById(cfg.id);
    const current = sel.value;
    sel.innerHTML = '<option value="">All</option>';
    uniqueSorted(resAllRecords.map(cfg.getter)).forEach(v => sel.add(new Option(v, v)));
    if ([...sel.options].some(o => o.value === current)) {
      sel.value = current;
    }
  });
}

function resPopulateAddCountryOptions() {
  const sel = document.getElementById("addPocCountry");
  RES_COUNTRY_LIST.forEach(c => sel.add(new Option(c, c)));
}

/* ==========================================================================
   SUMMARY CARDS
   ========================================================================== */
function resComputeSummary() {
  const total = resAllRecords.length;
  const active = resAllRecords.filter(r => r.status === "Active").length;
  const inactive = resAllRecords.filter(r => r.status === "Inactive").length;
  const onLeave = resAllRecords.filter(r => r.status === "Leave").length;
  return { total, active, inactive, onLeave };
}

function resRenderSummary() {
  const s = resComputeSummary();
  const grid = document.getElementById("resSummaryGrid");
  const cards = [
    { cls: "sc-total", icon: "bi-collection", value: s.total, label: "Total Records" },
    { cls: "sc-resolved", icon: "bi-person-check-fill", value: s.active, label: "Active POCs" },
    { cls: "sc-expiring", icon: "bi-person-x-fill", value: s.inactive, label: "Inactive POCs" },
    { cls: "sc-pending", icon: "bi-person-dash-fill", value: s.onLeave, label: "On Leave" }
  ];
  grid.innerHTML = cards.map(c => `
    <div class="summary-card ${c.cls}">
      <div class="sc-top"><span class="sc-icon"><i class="bi ${c.icon}"></i></span></div>
      <div class="sc-value">${c.value}</div>
      <div class="sc-label">${c.label}</div>
    </div>
  `).join("");
}

/* ==========================================================================
   FILTER + SEARCH + SORT PIPELINE
   ========================================================================== */
function resApplyFilters() {
  const q = document.getElementById("resSearchInput").value.trim().toLowerCase();
  const country = document.getElementById("resFilterCountry").value;
  const environment = document.getElementById("resFilterEnvironment").value;
  const status = document.getElementById("resFilterStatus").value;
  const escalation = document.getElementById("resFilterEscalation").value;
  const teamDL = document.getElementById("resFilterTeamDL").value;

  resFilteredRecords = resAllRecords.filter(r => {
    if (country && r.country !== country) return false;
    if (environment && r.environment !== environment) return false;
    if (status && r.status !== status) return false;
    if (escalation && r.escalationLead !== escalation) return false;
    if (teamDL && r.teamDL !== teamDL) return false;

    if (q) {
      const pocNames = r.pocs.map(p => p.name).join(" ");
      const pocEmails = r.pocs.map(p => p.email).join(" ");
      const haystack = [
        r.application, r.country, r.environment, r.teamDL,
        pocNames, pocEmails,
        r.escalationLead, r.escalationLeadEmail, r.status
      ].join(" ").toLowerCase();
      if (!haystack.includes(q)) return false;
    }
    return true;
  });

  resSortRecords();
  resRenderTable();
}

function resSortRecords() {
  const { key, dir } = resSortState;
  resFilteredRecords.sort((a, b) => {
    let va = a[key], vb = b[key];
    if (typeof va === "string") va = va.toLowerCase();
    if (typeof vb === "string") vb = vb.toLowerCase();
    if (va < vb) return dir === "asc" ? -1 : 1;
    if (va > vb) return dir === "asc" ? 1 : -1;
    return 0;
  });
}

/* ==========================================================================
   TABLE RENDER
   ========================================================================== */
function resRenderTable() {
  const body = document.getElementById("resRecordsBody");
  const empty = document.getElementById("resEmptyState");
  const countEl = document.getElementById("resResultsCount");
  const table = document.getElementById("resRecordsTable");
  const exportBtn = document.getElementById("resExportBtn");

  countEl.textContent = `${resFilteredRecords.length} record${resFilteredRecords.length === 1 ? "" : "s"}`;
  exportBtn.disabled = resFilteredRecords.length === 0;

  if (resFilteredRecords.length === 0) {
    body.innerHTML = "";
    table.style.display = "none";
    empty.classList.remove("d-none");
    document.getElementById("resPaginationBar").style.visibility = "hidden";
    return;
  }
  table.style.display = "table";
  empty.classList.add("d-none");
  document.getElementById("resPaginationBar").style.visibility = "visible";

  const totalPages = Math.max(1, Math.ceil(resFilteredRecords.length / RES_PAGE_SIZE));
  resCurrentPage = Math.min(resCurrentPage, totalPages);
  const start = (resCurrentPage - 1) * RES_PAGE_SIZE;
  const pageItems = resFilteredRecords.slice(start, start + RES_PAGE_SIZE);
  const rangeStart = resFilteredRecords.length === 0 ? 0 : start + 1;
  const rangeEnd = Math.min(start + RES_PAGE_SIZE, resFilteredRecords.length);

  body.innerHTML = pageItems.map(r => `
      <tr>
        <td class="cell-app">
          <span class="app-name">${escapeHtml(r.application)}</span>
          <span class="app-sub">Gear ID ${escapeHtml(r.gearId)} &middot; ${escapeHtml(r.country)}</span>
        </td>
        <td>${resEnvBadge(r.environment)}</td>
        <td class="cell-owner">
          ${r.pocs.map(p => `<span class="owner-name">${escapeHtml(p.name)}</span>`).join("")}
        </td>
        <td class="cell-owner">
          ${r.pocs.map(p => `<span class="owner-role">${escapeHtml(p.email)}</span>`).join("")}
        </td>
        <td class="cell-owner">
          <span class="owner-name">${escapeHtml(r.escalationLead)}</span>
          <span class="owner-role">${escapeHtml(r.escalationLeadEmail)}</span>
        </td>
        <td class="cell-date">${escapeHtml(r.teamDL)}</td>
        <td>${resStatusBadge(r.status)}</td>
        <td class="cell-date">${formatDate(r.lastVerified)}</td>
        <td class="td-action">
          <div class="action-buttons">
            <button class="btn-view-row" data-id="${r.id}" title="View full details"><i class="bi bi-eye"></i> View</button>
            <button class="btn-update-row" data-id="${r.id}" title="Update this record"><i class="bi bi-pencil"></i> Update</button>
            <button class="btn-delete-row" data-id="${r.id}" title="Delete this record"><i class="bi bi-trash3"></i> Delete</button>
          </div>
        </td>
      </tr>
    `).join("");

  body.querySelectorAll(".btn-view-row").forEach(btn => {
    btn.addEventListener("click", () => resOpenViewModal(btn.dataset.id));
  });
  body.querySelectorAll(".btn-update-row").forEach(btn => {
    btn.addEventListener("click", () => resOpenEditModal(btn.dataset.id));
  });
  body.querySelectorAll(".btn-delete-row").forEach(btn => {
    btn.addEventListener("click", () => resOpenDeleteConfirm(btn.dataset.id));
  });

  document.getElementById("resPageInfo").textContent =
    `Showing ${rangeStart}-${rangeEnd} of ${resFilteredRecords.length} results`;

  document.getElementById("resFirstPage").disabled = resCurrentPage <= 1;
  document.getElementById("resPrevPage").disabled = resCurrentPage <= 1;
  document.getElementById("resNextPage").disabled = resCurrentPage >= totalPages;
  document.getElementById("resLastPage").disabled = resCurrentPage >= totalPages;

  const pageJumpInput = document.getElementById("resPageJumpInput");
  pageJumpInput.max = String(totalPages);
  if (document.activeElement !== pageJumpInput) {
    pageJumpInput.value = String(resCurrentPage);
  }
  document.getElementById("resPageJumpTotal").textContent = `of ${totalPages}`;

  document.querySelectorAll("#resRecordsTable thead th[data-sort]").forEach(th => {
    th.querySelector(".sort-caret")?.remove();
    if (th.dataset.sort === resSortState.key) {
      const caret = document.createElement("span");
      caret.className = "sort-caret";
      caret.innerHTML = resSortState.dir === "asc" ? "\u25B2" : "\u25BC";
      th.appendChild(caret);
    }
  });
}

/* ==========================================================================
   ADD POC
   ========================================================================== */
function resOpenAddModal() {
  resEditingId = null;
  document.getElementById("addPocForm").reset();
  document.getElementById("addPocModalEyebrow").textContent = "New Record";
  document.getElementById("addPocModalTitle").textContent = "Add POC";
  document.getElementById("addPocSubmitBtn").textContent = "Add POC";
  const modal = new bootstrap.Modal(document.getElementById("addPocModal"));
  modal.show();
}

function resOpenEditModal(id) {
  const r = resAllRecords.find(x => x.id === id);
  if (!r) return;
  resEditingId = id;

  document.getElementById("addPocGearId").value = r.gearId;
  document.getElementById("addPocCountry").value = r.country;
  document.getElementById("addPocAppName").value = r.appName;
  document.getElementById("addPocEnvironment").value = r.environment;
  document.getElementById("addPocStatus").value = r.status;
  document.getElementById("addPocTeamDL").value = r.teamDL;
  document.getElementById("addPoc1Name").value = r.poc1Name;
  document.getElementById("addPoc1Email").value = r.poc1Email;
  document.getElementById("addPoc2Name").value = r.poc2Name;
  document.getElementById("addPoc2Email").value = r.poc2Email;
  document.getElementById("addPocEscName").value = r.escalationLead;
  document.getElementById("addPocEscEmail").value = r.escalationLeadEmail;
  document.getElementById("addPocLastVerified").value = r.lastVerified;

  document.getElementById("addPocModalEyebrow").textContent = "Edit Record";
  document.getElementById("addPocModalTitle").textContent = "Update Resource Record";
  document.getElementById("addPocSubmitBtn").textContent = "Save Changes";
  const modal = new bootstrap.Modal(document.getElementById("addPocModal"));
  modal.show();
}

function resHandleAddSubmit(e) {
  e.preventDefault();
  const form = document.getElementById("addPocForm");
  if (!form.checkValidity()) {
    form.reportValidity();
    return;
  }

  const gearId = document.getElementById("addPocGearId").value.trim();
  const country = document.getElementById("addPocCountry").value;
  const name = document.getElementById("addPocAppName").value.trim();
  const environment = document.getElementById("addPocEnvironment").value;
  const status = document.getElementById("addPocStatus").value;
  const teamDL = document.getElementById("addPocTeamDL").value.trim();
  const poc1Name = document.getElementById("addPoc1Name").value.trim();
  const poc1Email = document.getElementById("addPoc1Email").value.trim();
  const poc2Name = document.getElementById("addPoc2Name").value.trim();
  const poc2Email = document.getElementById("addPoc2Email").value.trim();
  const escalationLead = document.getElementById("addPocEscName").value.trim();
  const escalationLeadEmail = document.getElementById("addPocEscEmail").value.trim();
  const lastVerifiedInput = document.getElementById("addPocLastVerified").value;
  const lastVerified = lastVerifiedInput || new Date().toISOString().slice(0, 10);

  const application = `${gearId} - ${country} - ${name}`;
  const pocs = [{ name: poc1Name, email: poc1Email }, { name: poc2Name, email: poc2Email }].filter(p => p.name);

  if (resEditingId) {
    const idx = resAllRecords.findIndex(r => r.id === resEditingId);
    if (idx !== -1) {
      resAllRecords[idx] = {
        ...resAllRecords[idx],
        application, country, appName: name, gearId, environment, status, teamDL,
        poc1Name, poc1Email, poc2Name, poc2Email,
        escalationLead, escalationLeadEmail, lastVerified, pocs
      };
    }
    resEditingId = null;
    showToast("Resource record updated.");
  } else {
    const newRecord = {
      id: `res-new-${resNextSeq++}`,
      application, country, appName: name, gearId, environment, status, teamDL,
      poc1Name, poc1Email, poc2Name, poc2Email,
      escalationLead, escalationLeadEmail, lastVerified, pocs
    };
    resAllRecords.unshift(newRecord);
    showToast("POC record added.");
  }

  resRefreshFilterOptions();
  resRenderSummary();
  resCurrentPage = 1;
  resApplyFilters();

  const modalEl = document.getElementById("addPocModal");
  bootstrap.Modal.getInstance(modalEl)?.hide();
}

/* ==========================================================================
   VIEW RESOURCE RECORD (read-only)
   ========================================================================== */
function resOpenViewModal(id) {
  const r = resAllRecords.find(x => x.id === id);
  if (!r) return;

  document.getElementById("viewPocGearId").textContent = `Gear ID ${r.gearId}`;
  document.getElementById("viewPocTitle").textContent = r.application;

  const pocRows = r.pocs.map((p, i) => `
      <div class="detail-item">
        <div class="di-label">POC ${i + 1} Name</div>
        <div class="di-value">${escapeHtml(p.name)}</div>
      </div>
      <div class="detail-item">
        <div class="di-label">POC ${i + 1} Email</div>
        <div class="di-value mono">${escapeHtml(p.email)}</div>
      </div>
    `).join("");

  document.getElementById("viewPocBody").innerHTML = `
    <div class="detail-section-title">Application</div>
    <div class="detail-grid">
      <div class="detail-item">
        <div class="di-label">Gear ID</div>
        <div class="di-value mono">${escapeHtml(r.gearId)}</div>
      </div>
      <div class="detail-item">
        <div class="di-label">Country</div>
        <div class="di-value">${escapeHtml(r.country)}</div>
      </div>
      <div class="detail-item">
        <div class="di-label">Environment</div>
        <div class="di-value">${resEnvBadge(r.environment)}</div>
      </div>
      <div class="detail-item">
        <div class="di-label">Status</div>
        <div class="di-value">${resStatusBadge(r.status)}</div>
      </div>
    </div>

    <div class="detail-section-title">POCs</div>
    <div class="detail-grid">
      ${pocRows || '<div class="detail-item full"><div class="di-value">No POCs on file.</div></div>'}
    </div>

    <div class="detail-section-title">Escalation &amp; Team</div>
    <div class="detail-grid">
      <div class="detail-item">
        <div class="di-label">Escalation Lead</div>
        <div class="di-value">${escapeHtml(r.escalationLead)}</div>
      </div>
      <div class="detail-item">
        <div class="di-label">Escalation Lead Email</div>
        <div class="di-value mono">${escapeHtml(r.escalationLeadEmail)}</div>
      </div>
      <div class="detail-item">
        <div class="di-label">Team DL</div>
        <div class="di-value mono">${escapeHtml(r.teamDL)}</div>
      </div>
      <div class="detail-item">
        <div class="di-label">Last Verified</div>
        <div class="di-value">${formatDate(r.lastVerified)}</div>
      </div>
    </div>
  `;

  const modal = new bootstrap.Modal(document.getElementById("viewPocModal"));
  modal.show();
}

/* ==========================================================================
   DELETE POC RECORD
   ========================================================================== */
function resOpenDeleteConfirm(id) {
  const r = resAllRecords.find(x => x.id === id);
  if (!r) return;
  resPendingDeleteId = id;
  document.getElementById("deletePocName").textContent = r.application;
  const modal = new bootstrap.Modal(document.getElementById("deletePocModal"));
  modal.show();
}

function resConfirmDelete() {
  if (!resPendingDeleteId) return;
  resAllRecords = resAllRecords.filter(r => r.id !== resPendingDeleteId);
  resPendingDeleteId = null;

  resRefreshFilterOptions();
  resRenderSummary();
  resCurrentPage = 1;
  resApplyFilters();

  const modalEl = document.getElementById("deletePocModal");
  bootstrap.Modal.getInstance(modalEl)?.hide();
}

/* ==========================================================================
   EXPORT (exports all currently filtered records to an Excel file)
   ========================================================================== */
const RES_EXPORT_COLUMNS = [
  { header: "Application", key: "application" },
  { header: "Gear ID", key: "gearId" },
  { header: "Country", key: "country" },
  { header: "Environment", key: "environment" },
  { header: "POC 1 Name", key: "poc1Name" },
  { header: "POC 1 Email", key: "poc1Email" },
  { header: "POC 2 Name", key: "poc2Name" },
  { header: "POC 2 Email", key: "poc2Email" },
  { header: "Team DL", key: "teamDL" },
  { header: "Escalation Lead", key: "escalationLead" },
  { header: "Escalation Lead Email", key: "escalationLeadEmail" },
  { header: "Status", key: "status" },
  { header: "Last Verified", key: "lastVerified" }
];

function resDownloadAllRecords() {
  if (!resFilteredRecords.length) return;

  const rows = resFilteredRecords.map(r => {
    const row = {};
    RES_EXPORT_COLUMNS.forEach(col => {
      const raw = r[col.key];
      row[col.header] = (raw === undefined || raw === null || raw === "") ? "\u2014" : raw;
    });
    return row;
  });

  const worksheet = XLSX.utils.json_to_sheet(rows, { header: RES_EXPORT_COLUMNS.map(c => c.header) });
  worksheet["!cols"] = RES_EXPORT_COLUMNS.map(c => ({ wch: Math.max(12, Math.min(42, c.header.length + 6)) }));

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Resource Inventory");

  const dateStamp = new Date().toISOString().slice(0, 10);
  XLSX.writeFile(workbook, `resource_inventory_export_${resFilteredRecords.length}records_${dateStamp}.xlsx`);
}

/* ==========================================================================
   IMPORT (bulk-load resource records from an Excel/CSV file)
   ========================================================================== */

// Normalizes a header string for matching: trims, lowercases, and collapses
// internal whitespace, so "Last Verified", "last verified", and "Last  Verified "
// all resolve to the same key.
function resNormalizeHeader(header) {
  return String(header).trim().toLowerCase().replace(/\s+/g, " ");
}

// Maps normalized header text -> internal field key. Includes the exact
// export headers plus common real-world variants (e.g. the source register's
// own "POC name(s)" / "POC email(s)" combined columns), so both a re-imported
// dashboard export AND the original source workbook map correctly.
const RES_IMPORT_HEADER_ALIASES = {
  "application": "application",
  "gear id": "gearId",
  "country": "country",
  "environment": "environment",
  "poc 1 name": "poc1Name",
  "poc 1 email": "poc1Email",
  "poc 2 name": "poc2Name",
  "poc 2 email": "poc2Email",
  "team dl": "teamDL",
  "escalation lead": "escalationLead",
  "escalation lead email": "escalationLeadEmail",
  "status": "status",
  "last verified": "lastVerified"
};

// Headers that hold multiple comma-separated POCs in a single cell (the
// source register's own format) instead of discrete POC 1 / POC 2 columns.
const RES_COMBINED_POC_NAME_HEADERS = ["poc name(s)", "poc names", "poc name", "pocs"];
const RES_COMBINED_POC_EMAIL_HEADERS = ["poc email(s)", "poc emails", "poc email"];

function resImportRecordsFromRows(rows) {
  let importedCount = 0;

  rows.forEach(row => {
    const rec = {};
    let combinedNames = null;
    let combinedEmails = null;

    Object.keys(row).forEach(header => {
      const normalized = resNormalizeHeader(header);
      let val = row[header];
      if (val === "\u2014" || val === undefined || val === null) val = "";
      val = String(val).trim();

      if (RES_COMBINED_POC_NAME_HEADERS.includes(normalized)) {
        combinedNames = val;
        return;
      }
      if (RES_COMBINED_POC_EMAIL_HEADERS.includes(normalized)) {
        combinedEmails = val;
        return;
      }
      const key = RES_IMPORT_HEADER_ALIASES[normalized];
      if (key) rec[key] = val;
    });

    if (!rec.application) return; // skip rows without at least an Application value

    // A combined "POC name(s)" / "POC email(s)" column (comma-separated)
    // takes precedence over discrete POC 1/2 columns when both are present,
    // and supports any number of POCs, not just two.
    if (combinedNames) {
      const names = combinedNames.split(",").map(s => s.trim()).filter(Boolean);
      const emails = (combinedEmails || "").split(",").map(s => s.trim());
      rec.pocs = names.map((name, i) => ({ name, email: emails[i] || "" }));
      rec.poc1Name = rec.pocs[0] ? rec.pocs[0].name : "";
      rec.poc1Email = rec.pocs[0] ? rec.pocs[0].email : "";
      rec.poc2Name = rec.pocs[1] ? rec.pocs[1].name : "";
      rec.poc2Email = rec.pocs[1] ? rec.pocs[1].email : "";
    }

    const parts = parseResourceApplicationParts(rec.application);
    if (!rec.gearId) rec.gearId = parts.gearId;
    if (!rec.country) rec.country = parts.country;
    rec.appName = parts.name;
    rec.status = rec.status || "Active";
    rec.lastVerified = rec.lastVerified || new Date().toISOString().slice(0, 10);
    if (!rec.pocs) rec.pocs = resBuildPocsList(rec);
    rec.id = `res-import-${resNextSeq++}`;

    resAllRecords.unshift(rec);
    importedCount++;
  });
  return importedCount;
}

function resHandleImportFile(e) {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (evt) => {
    try {
      const data = new Uint8Array(evt.target.result);
      const workbook = XLSX.read(data, { type: "array" });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(sheet, { defval: "", raw: false });
      const count = resImportRecordsFromRows(rows);

      resRefreshFilterOptions();
      resRenderSummary();
      resCurrentPage = 1;
      resApplyFilters();

      if (count > 0) {
        showToast(`${count} resource record${count === 1 ? "" : "s"} imported successfully.`);
      } else {
        showToast("No matching rows found in that file. Expected an \u2018Application\u2019 column at minimum.", "error");
      }
      // NOTE: once this page is connected to the SharePoint Resource
      // Inventory list, each imported row above should also be written to
      // that list here (e.g. via a Power Automate HTTP flow or the
      // SharePoint REST/Graph API) so the list stays in sync with what's
      // shown in the browser.
    } catch (err) {
      console.error(err);
      showToast("Could not read that file. Please upload a valid Excel or CSV export.", "error");
    }
  };
  reader.readAsArrayBuffer(file);
  e.target.value = ""; // allow re-selecting the same file later
}

/* ==========================================================================
   EVENTS
   ========================================================================== */
function resWireEvents() {
  const searchInput = document.getElementById("resSearchInput");
  const searchClear = document.getElementById("resSearchClear");

  searchInput.addEventListener("input", () => {
    searchClear.classList.toggle("d-none", searchInput.value.length === 0);
    resCurrentPage = 1;
    resApplyFilters();
  });
  searchClear.addEventListener("click", () => {
    searchInput.value = "";
    searchClear.classList.add("d-none");
    resCurrentPage = 1;
    resApplyFilters();
  });

  const RES_FILTER_IDS = [
    "resFilterCountry", "resFilterEnvironment", "resFilterStatus",
    "resFilterEscalation", "resFilterTeamDL"
  ];
  RES_FILTER_IDS.forEach(id => {
    document.getElementById(id).addEventListener("change", () => {
      resCurrentPage = 1;
      resApplyFilters();
    });
  });

  const resResetFilters = () => {
    RES_FILTER_IDS.forEach(id => { document.getElementById(id).value = ""; });
    searchInput.value = "";
    searchClear.classList.add("d-none");
    resCurrentPage = 1;
    resApplyFilters();
  };
  document.getElementById("resResetFiltersBtn").addEventListener("click", resResetFilters);
  document.getElementById("resEmptyResetBtn").addEventListener("click", resResetFilters);

  document.querySelectorAll("#resRecordsTable thead th[data-sort]").forEach(th => {
    th.addEventListener("click", () => {
      const key = th.dataset.sort;
      if (resSortState.key === key) {
        resSortState.dir = resSortState.dir === "asc" ? "desc" : "asc";
      } else {
        resSortState = { key, dir: "asc" };
      }
      resSortRecords();
      resRenderTable();
    });
  });

  document.getElementById("resFirstPage").addEventListener("click", () => {
    if (resCurrentPage > 1) { resCurrentPage = 1; resRenderTable(); }
  });
  document.getElementById("resPrevPage").addEventListener("click", () => {
    if (resCurrentPage > 1) { resCurrentPage--; resRenderTable(); }
  });
  document.getElementById("resNextPage").addEventListener("click", () => {
    resCurrentPage++; resRenderTable();
  });
  document.getElementById("resLastPage").addEventListener("click", () => {
    const totalPages = Math.max(1, Math.ceil(resFilteredRecords.length / RES_PAGE_SIZE));
    if (resCurrentPage < totalPages) { resCurrentPage = totalPages; resRenderTable(); }
  });

  const pageJumpInput = document.getElementById("resPageJumpInput");
  const goToTypedPage = () => {
    const totalPages = Math.max(1, Math.ceil(resFilteredRecords.length / RES_PAGE_SIZE));
    let target = parseInt(pageJumpInput.value, 10);
    if (!Number.isFinite(target)) target = resCurrentPage;
    target = Math.min(Math.max(target, 1), totalPages);
    resCurrentPage = target;
    resRenderTable();
  };
  pageJumpInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      goToTypedPage();
      pageJumpInput.blur();
    }
  });
  pageJumpInput.addEventListener("blur", () => {
    pageJumpInput.value = String(resCurrentPage);
  });

  const pageSizeSelect = document.getElementById("resPageSizeSelect");
  pageSizeSelect.value = String(RES_PAGE_SIZE);
  pageSizeSelect.addEventListener("change", (e) => {
    RES_PAGE_SIZE = parseInt(e.target.value, 10);
    resCurrentPage = 1;
    resRenderTable();
  });

  document.getElementById("resExportBtn").addEventListener("click", () => {
    resDownloadAllRecords();
  });

  document.getElementById("topbarAddPocBtn").addEventListener("click", resOpenAddModal);
  document.getElementById("addPocForm").addEventListener("submit", resHandleAddSubmit);
  document.getElementById("confirmDeletePocBtn").addEventListener("click", resConfirmDelete);

  document.getElementById("topbarImportPocBtn").addEventListener("click", () => {
    document.getElementById("resImportFileInput").click();
  });
  document.getElementById("resImportFileInput").addEventListener("change", resHandleImportFile);
}

/* ==========================================================================
   INIT
   ========================================================================== */
document.addEventListener("DOMContentLoaded", () => {
  loadResourceInventory();
  resPopulateAddCountryOptions();
  resRefreshFilterOptions();
  resRenderSummary();
  resWireEvents();
  resApplyFilters();
});
