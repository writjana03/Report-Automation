/* ==========================================================================
   ASM INVENTORY MOCK DATA
   One record per ASM (unique per country, incl. APAC). Coverage counts
   (apps managed, ADM/Non-ADM split, decom count) are NOT stored here -
   they are computed live against RAW_APP_INVENTORY at render time, the
   same way the summary cards on the other pages are computed.
   Power Automate / API integration will later replace loadAsmInventory()
   with a live fetch that returns objects in this same shape.
   ========================================================================== */

const RAW_ASM_INVENTORY = [
  {
    country: "AU",
    asmName: "Joseph Johnson",
    asmEmail: "joseph.johnson@company.com",
    teamDL: "L2-GI-APAC-AU@company.com",
    status: "Active",
    lastVerified: "2026-08-20",
    notes: ""
  },
  {
    country: "SG",
    asmName: "Emily Thomas",
    asmEmail: "emily.thomas@company.com",
    teamDL: "L2-GI-APAC-SG@company.com",
    status: "Active",
    lastVerified: "2026-08-20",
    notes: ""
  },
  {
    country: "MY",
    asmName: "Donald Rodriguez",
    asmEmail: "donald.rodriguez@company.com",
    teamDL: "L2-GI-APAC-MY@company.com",
    status: "Active",
    lastVerified: "2026-08-20",
    notes: ""
  },
  {
    country: "TH",
    asmName: "Susan Chan",
    asmEmail: "susan.chan@company.com",
    teamDL: "L2-GI-APAC-TH@company.com",
    status: "Active",
    lastVerified: "2026-08-20",
    notes: ""
  },
  {
    country: "TW",
    asmName: "Anand Garcia",
    asmEmail: "anand.garcia@company.com",
    teamDL: "L2-GI-APAC-TW@company.com",
    status: "Active",
    lastVerified: "2026-08-20",
    notes: ""
  },
  {
    country: "CN",
    asmName: "Tan Williams",
    asmEmail: "tan.williams@company.com",
    teamDL: "L2-GI-APAC-CN@company.com",
    status: "Active",
    lastVerified: "2026-08-20",
    notes: ""
  },
  {
    country: "ID",
    asmName: "Patricia Garcia",
    asmEmail: "patricia.garcia@company.com",
    teamDL: "L2-GI-APAC-ID@company.com",
    status: "Active",
    lastVerified: "2026-08-20",
    notes: ""
  },
  {
    country: "PH",
    asmName: "Margaret Anderson",
    asmEmail: "margaret.anderson@company.com",
    teamDL: "L2-GI-APAC-PH@company.com",
    status: "Leave",
    lastVerified: "2026-08-20",
    notes: "Currently on leave; route urgent items to the Team DL until return."
  },
  {
    country: "HK",
    asmName: "Nguyen Hill",
    asmEmail: "nguyen.hill@company.com",
    teamDL: "L2-GI-APAC-HK@company.com",
    status: "Inactive",
    lastVerified: "2026-08-20",
    notes: "Backfill in progress; Team DL is the active routing path for this country."
  },
  {
    country: "VN",
    asmName: "Patricia Scott",
    asmEmail: "patricia.scott@company.com",
    teamDL: "L2-GI-APAC-VN@company.com",
    status: "Active",
    lastVerified: "2026-08-20",
    notes: ""
  },
  {
    country: "NZ",
    asmName: "Betty Kim",
    asmEmail: "betty.kim@company.com",
    teamDL: "L2-GI-APAC-NZ@company.com",
    status: "Active",
    lastVerified: "2026-08-20",
    notes: ""
  },
  {
    country: "KR",
    asmName: "Anand Clark",
    asmEmail: "anand.clark@company.com",
    teamDL: "L2-GI-APAC-KR@company.com",
    status: "Active",
    lastVerified: "2026-08-20",
    notes: ""
  },
  {
    country: "APAC",
    asmName: "Donald Lewis",
    asmEmail: "donald.lewis@company.com",
    teamDL: "L2-GI-APAC-APAC@company.com",
    status: "Active",
    lastVerified: "2026-08-20",
    notes: ""
  },
];
