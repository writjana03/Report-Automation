/* ==========================================================================
   ASSIGNMENT GROUP PAGE
   Self-contained logic for the Assignment Group routing register. Reuses
   shared helpers already defined in script.js (escapeHtml, uniqueSorted) but
   keeps its own state so it never touches the Vulnerabilities, Application
   Inventory, or Resource Inventory pages' behavior.
   Power Automate / API integration will later replace loadAssignmentGroups()
   with a live fetch against the master routing tracker.
   ========================================================================== */

/* ==========================================================================
   STATE
   ========================================================================== */
let agAllRecords = [];
let agFilteredRecords = [];
let agCurrentPage = 1;
let AG_PAGE_SIZE = 10;
let agSortState = { key: "groupName", dir: "asc" };

/* ==========================================================================
   DATA LOADING (swap this for a live Power Automate / API call later)
   ========================================================================== */

// The source tracker files the UNIX team under "Other", but for routing
// purposes this page groups it with the rest of the Infrastructure (IS)
// teams (WinTel / Network / Middleware / Web Services / UNIX).
function agDisplayGroupType(row) {
  if (row.teamOrCountry === "UNIX Team") return "Infrastructure";
  return row.groupType;
}

// Application groups are keyed to a country/region code already (AU, SG,
// ... APAC). Infrastructure and Other/Security teams are region-wide, so
// they're attributed to APAC for the Country / Region filter.
function agDeriveCountry(row, displayType) {
  return displayType === "Application" ? row.teamOrCountry : "APAC";
}

function loadAssignmentGroups() {
  agAllRecords = RAW_ASSIGNMENT_GROUPS.map((r, i) => {
    const displayType = agDisplayGroupType(r);
    return {
      id: `ag-${i}`,
      groupName: r.groupName,
      groupType: displayType,
      teamOrCountry: r.teamOrCountry,
      country: agDeriveCountry(r, displayType),
      appCountCovered: r.appCountCovered,
      assignees: r.assignees,
      assigneesLabel: r.assignees.join(", "),
      assigneeCount: r.assignees.length,
      emailDL: r.emailDL
    };
  });
}

/* ==========================================================================
   BADGES
   ========================================================================== */
function agGroupTypeBadge(type) {
  const map = { Application: "badge-info", Infrastructure: "badge-success", Other: "badge-warning" };
  const labelMap = { Application: "Application", Infrastructure: "Infrastructure (IS)", Other: "Other / Security" };
  const cls = map[type] || "badge-neutral";
  return `<span class="badge-status ${cls}"><span class="dot"></span>${escapeHtml(labelMap[type] || type)}</span>`;
}

/* ==========================================================================
   FILTER OPTIONS
   ========================================================================== */
function agRefreshFilterOptions() {
  const sel = document.getElementById("agFilterCountry");
  const current = sel.value;
  sel.innerHTML = '<option value="">All</option>';
  uniqueSorted(agAllRecords.map(r => r.country)).forEach(v => sel.add(new Option(v, v)));
  if ([...sel.options].some(o => o.value === current)) {
    sel.value = current;
  }
}

/* ==========================================================================
   SUMMARY CARDS
   ========================================================================== */
function agComputeSummary() {
  const total = agAllRecords.length;
  const application = agAllRecords.filter(r => r.groupType === "Application").length;
  const infra = agAllRecords.filter(r => r.groupType === "Infrastructure").length;
  const other = agAllRecords.filter(r => r.groupType === "Other").length;
  return { total, application, infra, other };
}

function agRenderSummary() {
  const s = agComputeSummary();
  const grid = document.getElementById("agSummaryGrid");
  const cards = [
    { cls: "sc-total", icon: "bi-diagram-3-fill", value: s.total, label: "Total Assignment Groups", sub: "Total registered groups" },
    { cls: "sc-resolved", icon: "bi-collection-fill", value: s.application, label: "Application Groups", sub: "APAC regional app teams" },
    { cls: "sc-feedback", icon: "bi-hdd-network-fill", value: s.infra, label: "IS & Infra Teams", sub: "WinTel, Network, MW, WS, UNIX" },
    { cls: "sc-pending", icon: "bi-shield-lock-fill", value: s.other, label: "Governance / Security", sub: "SRT, ISO, Vuln Mgmt, Patching, DBAs" }
  ];
  grid.innerHTML = cards.map(c => `
    <div class="summary-card ${c.cls}">
      <div class="sc-top"><span class="sc-icon"><i class="bi ${c.icon}"></i></span></div>
      <div class="sc-value">${c.value}</div>
      <div class="sc-label">${c.label}</div>
      <div class="sc-sublabel">${c.sub}</div>
    </div>
  `).join("");
}

/* ==========================================================================
   FILTER + SEARCH + SORT PIPELINE
   ========================================================================== */
function agApplyFilters() {
  const q = document.getElementById("agSearchInput").value.trim().toLowerCase();
  const groupType = document.getElementById("agFilterGroupType").value;
  const country = document.getElementById("agFilterCountry").value;

  agFilteredRecords = agAllRecords.filter(r => {
    if (groupType && r.groupType !== groupType) return false;
    if (country && r.country !== country) return false;

    if (q) {
      const haystack = [r.groupName, r.assigneesLabel, r.emailDL].join(" ").toLowerCase();
      if (!haystack.includes(q)) return false;
    }
    return true;
  });

  agSortRecords();
  agRenderTable();
}

function agSortRecords() {
  const { key, dir } = agSortState;
  agFilteredRecords.sort((a, b) => {
    let va = a[key], vb = b[key];
    if (va === null || va === undefined) va = dir === "asc" ? Infinity : -Infinity;
    if (vb === null || vb === undefined) vb = dir === "asc" ? Infinity : -Infinity;
    if (typeof va === "string") va = va.toLowerCase();
    if (typeof vb === "string") vb = vb.toLowerCase();
    if (va < vb) return dir === "asc" ? -1 : 1;
    if (va > vb) return dir === "asc" ? 1 : -1;
    return 0;
  });
}

/* ==========================================================================
   TABLE RENDER
   ========================================================================== */
function agRenderTable() {
  const body = document.getElementById("agRecordsBody");
  const empty = document.getElementById("agEmptyState");
  const countEl = document.getElementById("agResultsCount");
  const table = document.getElementById("agRecordsTable");
  const exportBtn = document.getElementById("agExportBtn");

  countEl.textContent = `${agFilteredRecords.length} group${agFilteredRecords.length === 1 ? "" : "s"}`;
  exportBtn.disabled = agFilteredRecords.length === 0;

  if (agFilteredRecords.length === 0) {
    body.innerHTML = "";
    table.style.display = "none";
    empty.classList.remove("d-none");
    document.getElementById("agPaginationBar").style.visibility = "hidden";
    return;
  }
  table.style.display = "table";
  empty.classList.add("d-none");
  document.getElementById("agPaginationBar").style.visibility = "visible";

  const totalPages = Math.max(1, Math.ceil(agFilteredRecords.length / AG_PAGE_SIZE));
  agCurrentPage = Math.min(agCurrentPage, totalPages);
  const start = (agCurrentPage - 1) * AG_PAGE_SIZE;
  const pageItems = agFilteredRecords.slice(start, start + AG_PAGE_SIZE);
  const rangeStart = agFilteredRecords.length === 0 ? 0 : start + 1;
  const rangeEnd = Math.min(start + AG_PAGE_SIZE, agFilteredRecords.length);

  body.innerHTML = pageItems.map(r => `
      <tr>
        <td class="cell-app">
          <span class="app-name">${escapeHtml(r.groupName)}</span>
          <span class="app-sub">${escapeHtml(r.teamOrCountry)}</span>
        </td>
        <td>${agGroupTypeBadge(r.groupType)}</td>
        <td>${escapeHtml(r.country)}</td>
        <td class="cell-owner">
          ${r.assignees.map(a => `<span class="owner-name">${escapeHtml(a)}</span>`).join("")}
        </td>
        <td class="cell-date">${escapeHtml(r.emailDL)}</td>
        <td>${r.appCountCovered === null || r.appCountCovered === undefined ? "&mdash;" : escapeHtml(String(r.appCountCovered))}</td>
        <td class="td-action">
          <div class="action-buttons">
            <button class="btn-view-row" data-id="${r.id}" title="View group details"><i class="bi bi-eye"></i> View</button>
          </div>
        </td>
      </tr>
    `).join("");

  body.querySelectorAll(".btn-view-row").forEach(btn => {
    btn.addEventListener("click", () => agOpenViewModal(btn.dataset.id));
  });

  document.getElementById("agPageInfo").textContent =
    `Showing ${rangeStart}-${rangeEnd} of ${agFilteredRecords.length} results`;

  document.getElementById("agFirstPage").disabled = agCurrentPage <= 1;
  document.getElementById("agPrevPage").disabled = agCurrentPage <= 1;
  document.getElementById("agNextPage").disabled = agCurrentPage >= totalPages;
  document.getElementById("agLastPage").disabled = agCurrentPage >= totalPages;

  const pageJumpInput = document.getElementById("agPageJumpInput");
  pageJumpInput.max = String(totalPages);
  if (document.activeElement !== pageJumpInput) {
    pageJumpInput.value = String(agCurrentPage);
  }
  document.getElementById("agPageJumpTotal").textContent = `of ${totalPages}`;

  document.querySelectorAll("#agRecordsTable thead th[data-sort]").forEach(th => {
    th.querySelector(".sort-caret")?.remove();
    if (th.dataset.sort === agSortState.key) {
      const caret = document.createElement("span");
      caret.className = "sort-caret";
      caret.innerHTML = agSortState.dir === "asc" ? "\u25B2" : "\u25BC";
      th.appendChild(caret);
    }
  });
}

/* ==========================================================================
   VIEW ASSIGNMENT GROUP (read-only)
   ========================================================================== */
function agOpenViewModal(id) {
  const r = agAllRecords.find(x => x.id === id);
  if (!r) return;

  const typeLabelMap = { Application: "Application", Infrastructure: "Infrastructure (IS)", Other: "Other / Security" };
  document.getElementById("viewGroupType").textContent = typeLabelMap[r.groupType] || r.groupType;
  document.getElementById("viewGroupTitle").textContent = r.groupName;

  const assigneeRows = r.assignees.map((a, i) => `
      <div class="detail-item">
        <div class="di-label">Assignee ${i + 1}</div>
        <div class="di-value">${escapeHtml(a)}</div>
      </div>
    `).join("");

  document.getElementById("viewGroupBody").innerHTML = `
    <div class="detail-section-title">Group</div>
    <div class="detail-grid">
      <div class="detail-item">
        <div class="di-label">Group Type</div>
        <div class="di-value">${agGroupTypeBadge(r.groupType)}</div>
      </div>
      <div class="detail-item">
        <div class="di-label">Country / Region</div>
        <div class="di-value">${escapeHtml(r.country)}</div>
      </div>
      <div class="detail-item">
        <div class="di-label">Team / Coverage</div>
        <div class="di-value">${escapeHtml(r.teamOrCountry)}</div>
      </div>
      <div class="detail-item">
        <div class="di-label">App Coverage</div>
        <div class="di-value">${r.appCountCovered === null || r.appCountCovered === undefined ? "&mdash;" : escapeHtml(String(r.appCountCovered)) + " application(s)"}</div>
      </div>
    </div>

    <div class="detail-section-title">Assignee(s)</div>
    <div class="detail-grid">
      ${assigneeRows || '<div class="detail-item full"><div class="di-value">No assignees on file.</div></div>'}
    </div>

    <div class="detail-section-title">Routing</div>
    <div class="detail-grid">
      <div class="detail-item full">
        <div class="di-label">Email DL</div>
        <div class="di-value mono">${escapeHtml(r.emailDL)}</div>
      </div>
    </div>
  `;

  const modal = new bootstrap.Modal(document.getElementById("viewGroupModal"));
  modal.show();
}

/* ==========================================================================
   EXPORT (exports all currently filtered assignment groups to an Excel file)
   ========================================================================== */
const AG_EXPORT_COLUMNS = [
  { header: "Assignment Group", key: "groupName" },
  { header: "Group Type", key: "groupType" },
  { header: "Country / Region", key: "country" },
  { header: "Team / Coverage", key: "teamOrCountry" },
  { header: "Assignee(s)", key: "assigneesLabel" },
  { header: "Email DL", key: "emailDL" },
  { header: "App Coverage", key: "appCountCovered" }
];

function agDownloadAllRecords() {
  if (!agFilteredRecords.length) return;

  const rows = agFilteredRecords.map(r => {
    const row = {};
    AG_EXPORT_COLUMNS.forEach(col => {
      const raw = r[col.key];
      row[col.header] = (raw === undefined || raw === null || raw === "") ? "\u2014" : raw;
    });
    return row;
  });

  const worksheet = XLSX.utils.json_to_sheet(rows, { header: AG_EXPORT_COLUMNS.map(c => c.header) });
  worksheet["!cols"] = AG_EXPORT_COLUMNS.map(c => ({ wch: Math.max(12, Math.min(42, c.header.length + 6)) }));

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Assignment Groups");

  const dateStamp = new Date().toISOString().slice(0, 10);
  XLSX.writeFile(workbook, `assignment_group_export_${agFilteredRecords.length}records_${dateStamp}.xlsx`);
}

/* ==========================================================================
   EVENTS
   ========================================================================== */
function agWireEvents() {
  const searchInput = document.getElementById("agSearchInput");
  const searchClear = document.getElementById("agSearchClear");

  searchInput.addEventListener("input", () => {
    searchClear.classList.toggle("d-none", searchInput.value.length === 0);
    agCurrentPage = 1;
    agApplyFilters();
  });
  searchClear.addEventListener("click", () => {
    searchInput.value = "";
    searchClear.classList.add("d-none");
    agCurrentPage = 1;
    agApplyFilters();
  });

  const AG_FILTER_IDS = ["agFilterGroupType", "agFilterCountry"];
  AG_FILTER_IDS.forEach(id => {
    document.getElementById(id).addEventListener("change", () => {
      agCurrentPage = 1;
      agApplyFilters();
    });
  });

  const agResetFilters = () => {
    AG_FILTER_IDS.forEach(id => { document.getElementById(id).value = ""; });
    searchInput.value = "";
    searchClear.classList.add("d-none");
    agCurrentPage = 1;
    agApplyFilters();
  };
  document.getElementById("agResetFiltersBtn").addEventListener("click", agResetFilters);
  document.getElementById("agEmptyResetBtn").addEventListener("click", agResetFilters);

  document.querySelectorAll("#agRecordsTable thead th[data-sort]").forEach(th => {
    th.addEventListener("click", () => {
      const key = th.dataset.sort;
      if (agSortState.key === key) {
        agSortState.dir = agSortState.dir === "asc" ? "desc" : "asc";
      } else {
        agSortState = { key, dir: "asc" };
      }
      agSortRecords();
      agRenderTable();
    });
  });

  document.getElementById("agFirstPage").addEventListener("click", () => {
    if (agCurrentPage > 1) { agCurrentPage = 1; agRenderTable(); }
  });
  document.getElementById("agPrevPage").addEventListener("click", () => {
    if (agCurrentPage > 1) { agCurrentPage--; agRenderTable(); }
  });
  document.getElementById("agNextPage").addEventListener("click", () => {
    agCurrentPage++; agRenderTable();
  });
  document.getElementById("agLastPage").addEventListener("click", () => {
    const totalPages = Math.max(1, Math.ceil(agFilteredRecords.length / AG_PAGE_SIZE));
    if (agCurrentPage < totalPages) { agCurrentPage = totalPages; agRenderTable(); }
  });

  const pageJumpInput = document.getElementById("agPageJumpInput");
  const goToTypedPage = () => {
    const totalPages = Math.max(1, Math.ceil(agFilteredRecords.length / AG_PAGE_SIZE));
    let target = parseInt(pageJumpInput.value, 10);
    if (!Number.isFinite(target)) target = agCurrentPage;
    target = Math.min(Math.max(target, 1), totalPages);
    agCurrentPage = target;
    agRenderTable();
  };
  pageJumpInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      goToTypedPage();
      pageJumpInput.blur();
    }
  });
  pageJumpInput.addEventListener("blur", () => {
    pageJumpInput.value = String(agCurrentPage);
  });

  const pageSizeSelect = document.getElementById("agPageSizeSelect");
  pageSizeSelect.value = String(AG_PAGE_SIZE);
  pageSizeSelect.addEventListener("change", (e) => {
    AG_PAGE_SIZE = parseInt(e.target.value, 10);
    agCurrentPage = 1;
    agRenderTable();
  });

  document.getElementById("agExportBtn").addEventListener("click", () => {
    agDownloadAllRecords();
  });
}

/* ==========================================================================
   INIT
   ========================================================================== */
document.addEventListener("DOMContentLoaded", () => {
  loadAssignmentGroups();
  agRefreshFilterOptions();
  agRenderSummary();
  agWireEvents();
  agApplyFilters();
});
